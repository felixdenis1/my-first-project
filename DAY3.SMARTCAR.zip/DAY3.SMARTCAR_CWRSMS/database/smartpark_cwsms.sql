-- Create the database
CREATE DATABASE IF NOT EXISTS smartpark_cwsms;
USE smartpark_cwsms;

-- Users table for authentication
CREATE TABLE users (
  id INT AUTO_INCREMENT PRIMARY KEY,
  username VARCHAR(50) NOT NULL UNIQUE,
  password VARCHAR(255) NOT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Cars table
CREATE TABLE cars (
  plate_number VARCHAR(20) PRIMARY KEY,
  car_type VARCHAR(50) NOT NULL,
  car_size VARCHAR(20) NOT NULL,
  driver_name VARCHAR(100) NOT NULL,
  phone_number VARCHAR(20) NOT NULL
);

-- Packages table
CREATE TABLE packages (
  package_number INT AUTO_INCREMENT PRIMARY KEY,
  package_name VARCHAR(50) NOT NULL,
  package_description TEXT NOT NULL,
  package_price DECIMAL(10, 2) NOT NULL
);

-- Service details table
CREATE TABLE service_details (
  record_number INT AUTO_INCREMENT PRIMARY KEY,
  service_date DATETIME DEFAULT CURRENT_TIMESTAMP,
  plate_number VARCHAR(20) NOT NULL,
  package_number INT NOT NULL,
  FOREIGN KEY (plate_number) REFERENCES cars(plate_number),
  FOREIGN KEY (package_number) REFERENCES packages(package_number)
);

-- Payments table
CREATE TABLE payments (
  payment_number INT AUTO_INCREMENT PRIMARY KEY,
  amount_paid DECIMAL(10, 2) NOT NULL,
  payment_date DATETIME DEFAULT CURRENT_TIMESTAMP,
  record_number INT NOT NULL,
  FOREIGN KEY (record_number) REFERENCES service_details(record_number)
);

-- Insert predefined packages
INSERT INTO packages (package_name, package_description, package_price) VALUES
('Basic Wash', 'Exterior hand wash', 5000.00),
('Classic Wash', 'Interior hand wash', 10000.00),
('Premium Wash', 'Exterior + Interior wash', 20000.00);

-- Insert sample cars
INSERT INTO cars (plate_number, car_type, car_size, driver_name, phone_number) VALUES
('RAA123A', 'Toyota RAV4', 'Medium', 'John Doe', '0781234567'),
('RAB456B', 'Land Cruiser', 'Large', 'Jane Smith', '0782345678'),
('RAC789C', 'Honda Fit', 'Small', 'Robert Johnson', '0783456789'),
('RAD012D', 'Mazda CX-5', 'Medium', 'Emily Davis', '0784567890'),
('RAE345E', 'Toyota Hilux', 'Large', 'Michael Wilson', '0785678901');

-- Insert a test user (username: admin, password: admin123)
-- Password is hashed using bcrypt (cost factor 10)
INSERT INTO users (username, password) VALUES
('admin', '$2b$10$N9qo8uLOickgx2ZMRZoMy.MrYrKJ0VnG39GZ6jJYv5H3H8jU7nJ1K');

-- Insert sample services and payments
INSERT INTO service_details (plate_number, package_number) VALUES
('RAA123A', 1),
('RAB456B', 2),
('RAC789C', 3),
('RAD012D', 1),
('RAE345E', 2);

-- Corresponding payments will be automatically calculated based on package prices
INSERT INTO payments (amount_paid, record_number) VALUES
(5000.00, 1),
(10000.00, 2),
(20000.00, 3),
(5000.00, 4),
(10000.00, 5);