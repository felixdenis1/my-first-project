import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { format } from 'date-fns';

const Services = () => {
  const [services, setServices] = useState([]);
  const [cars, setCars] = useState([]);
  const [packages, setPackages] = useState([]);
  const [formData, setFormData] = useState({
    plate_number: '',
    package_number: '',
  });
  const [editData, setEditData] = useState({
    record_number: '',
    plate_number: '',
    package_number: '',
  });
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);
  const [success, setSuccess] = useState(null);
  const [isEditing, setIsEditing] = useState(false);

  useEffect(() => {
    fetchServices();
    fetchCars();
    fetchPackages();
  }, []);

  const fetchServices = async () => {
    try {
      setLoading(true);
      const token = localStorage.getItem('token');
      const response = await axios.get('http://localhost:5000/api/services', {
        headers: { Authorization: `Bearer ${token}` },
      });
      setServices(response.data);
      setError(null);
    } catch (error) {
      console.error('Error fetching services:', error);
      setError('Failed to fetch services. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  const fetchCars = async () => {
    try {
      const token = localStorage.getItem('token');
      const response = await axios.get('http://localhost:5000/api/cars', {
        headers: { Authorization: `Bearer ${token}` },
      });
      setCars(response.data);
    } catch (error) {
      console.error('Error fetching cars:', error);
      setError('Failed to fetch cars. Please try again.');
    }
  };

  const fetchPackages = async () => {
    try {
      const token = localStorage.getItem('token');
      const response = await axios.get('http://localhost:5000/api/packages', {
        headers: { Authorization: `Bearer ${token}` },
      });
      setPackages(response.data);
    } catch (error) {
      console.error('Error fetching packages:', error);
      setError('Failed to fetch packages. Please try again.');
    }
  };

  const handleChange = (e) => {
    const { name, value } = e.target;
    if (isEditing) {
      setEditData({ ...editData, [name]: value });
    } else {
      setFormData({ ...formData, [name]: value });
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError(null);
    setSuccess(null);
    
    try {
      const token = localStorage.getItem('token');
      const response = await axios.post(
        'http://localhost:5000/api/services', 
        formData, 
        {
          headers: { 
            Authorization: `Bearer ${token}`,
            'Content-Type': 'application/json'
          }
        }
      );
      
      setSuccess('Service recorded successfully!');
      fetchServices();
      setFormData({
        plate_number: '',
        package_number: '',
      });
    } catch (error) {
      console.error('Error adding service:', error);
      if (error.response) {
        if (error.response.status === 404) {
          setError(error.response.data.error || 'Car or package not found');
        } else {
          setError(error.response.data.error || 'Failed to record service');
        }
      } else {
        setError('Network error. Please try again.');
      }
    }
  };

  const handleEditSubmit = async (e) => {
    e.preventDefault();
    setError(null);
    setSuccess(null);
    
    try {
      const token = localStorage.getItem('token');
      const response = await axios.put(
        `http://localhost:5000/api/services/${editData.record_number}`,
        {
          plate_number: editData.plate_number,
          package_number: editData.package_number
        },
        {
          headers: { 
            Authorization: `Bearer ${token}`,
            'Content-Type': 'application/json'
          }
        }
      );
      
      setSuccess('Service updated successfully!');
      fetchServices();
      setIsEditing(false);
      setEditData({
        record_number: '',
        plate_number: '',
        package_number: '',
      });
    } catch (error) {
      console.error('Error updating service:', error);
      if (error.response) {
        if (error.response.status === 404) {
          setError(error.response.data.error || 'Service, car, or package not found');
        } else {
          setError(error.response.data.error || 'Failed to update service');
        }
      } else {
        setError('Network error. Please try again.');
      }
    }
  };

  const handleEdit = (service) => {
    setIsEditing(true);
    setEditData({
      record_number: service.record_number,
      plate_number: service.plate_number,
      package_number: service.package_number,
    });
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleCancelEdit = () => {
    setIsEditing(false);
    setEditData({
      record_number: '',
      plate_number: '',
      package_number: '',
    });
  };

  const handleDelete = async (recordNumber) => {
    if (!window.confirm('Are you sure you want to delete this service record?')) {
      return;
    }
    
    try {
      const token = localStorage.getItem('token');
      await axios.delete(`http://localhost:5000/api/services/${recordNumber}`, {
        headers: { Authorization: `Bearer ${token}` }
      });
      
      setSuccess('Service deleted successfully!');
      fetchServices();
    } catch (error) {
      console.error('Error deleting service:', error);
      setError('Failed to delete service. Please try again.');
    }
  };

  return (
    <div style={styles.container}>
      <h2>Service Management</h2>
      
      {error && (
        <div style={styles.errorAlert}>
          {error}
          <button onClick={() => setError(null)} style={styles.alertCloseButton}>
            &times;
          </button>
        </div>
      )}
      
      {success && (
        <div style={styles.successAlert}>
          {success}
          <button onClick={() => setSuccess(null)} style={styles.alertCloseButton}>
            &times;
          </button>
        </div>
      )}

      <div style={styles.formContainer}>
        <h3>{isEditing ? 'Edit Service' : 'Record New Service'}</h3>
        <form onSubmit={isEditing ? handleEditSubmit : handleSubmit} style={styles.form}>
          {isEditing && (
            <div style={styles.formGroup}>
              <label>Record Number:</label>
              <input
                type="text"
                value={editData.record_number}
                readOnly
                style={styles.readOnlyInput}
              />
            </div>
          )}
          <div style={styles.formGroup}>
            <label>Car:</label>
            <select
              name="plate_number"
              value={isEditing ? editData.plate_number : formData.plate_number}
              onChange={handleChange}
              required
              style={styles.select}
            >
              <option value="">Select car</option>
              {cars.map((car) => (
                <option key={car.plate_number} value={car.plate_number}>
                  {car.plate_number} - {car.driver_name} ({car.car_type})
                </option>
              ))}
            </select>
          </div>
          <div style={styles.formGroup}>
            <label>Package:</label>
            <select
              name="package_number"
              value={isEditing ? editData.package_number : formData.package_number}
              onChange={handleChange}
              required
              style={styles.select}
            >
              <option value="">Select package</option>
              {packages.map((pkg) => (
                <option key={pkg.package_number} value={pkg.package_number}>
                  {pkg.package_name} - {pkg.package_price} RWF
                </option>
              ))}
            </select>
          </div>
          <div style={{...styles.buttonGroup, gridColumn: '1 / -1'}}>
            <button 
              type="submit" 
              style={styles.submitButton}
              disabled={loading}
            >
              {loading ? 'Processing...' : (isEditing ? 'Update Service' : 'Record Service')}
            </button>
            {isEditing && (
              <button 
                type="button" 
                onClick={handleCancelEdit}
                style={styles.cancelButton}
              >
                Cancel
              </button>
            )}
          </div>
        </form>
      </div>
      
      <div style={styles.tableContainer}>
        <h3>Service History</h3>
        {loading ? (
          <div style={styles.loading}>Loading services...</div>
        ) : services.length === 0 ? (
          <div style={styles.noData}>No services found</div>
        ) : (
          <div style={styles.tableWrapper}>
            <table style={styles.table}>
              <thead>
                <tr>
                  <th style={styles.th}>Record #</th>
                  <th style={styles.th}>Plate Number</th>
                  <th style={styles.th}>Driver</th>
                  <th style={styles.th}>Phone</th>
                  <th style={styles.th}>Package</th>
                  <th style={styles.th}>Description</th>
                  <th style={styles.th}>Price (RWF)</th>
                  <th style={styles.th}>Service Date</th>
                  <th style={styles.th}>Payment Date</th>
                  <th style={styles.th}>Actions</th>
                </tr>
              </thead>
              <tbody>
                {services.map((service) => (
                  <tr key={service.record_number}>
                    <td style={styles.td}>{service.record_number}</td>
                    <td style={styles.td}>{service.plate_number}</td>
                    <td style={styles.td}>{service.driver_name}</td>
                    <td style={styles.td}>{service.phone_number}</td>
                    <td style={styles.td}>{service.package_name}</td>
                    <td style={styles.td}>{service.package_description}</td>
                    <td style={styles.td}>{service.package_price.toLocaleString()}</td>
                    <td style={styles.td}>
                      {format(new Date(service.service_date), 'PPpp')}
                    </td>
                    <td style={styles.td}>
                      {service.payment_date ? 
                        format(new Date(service.payment_date), 'PPpp') : 
                        'N/A'}
                    </td>
                    <td style={styles.td}>
                      <button 
                        onClick={() => handleEdit(service)}
                        style={styles.editButton}
                      >
                        Edit
                      </button>
                      <button 
                        onClick={() => handleDelete(service.record_number)}
                        style={styles.deleteButton}
                      >
                        Delete
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  );
};

const styles = {
  container: {
    padding: '20px',
    maxWidth: '1200px',
    margin: '0 auto',
  },
  formContainer: {
    marginBottom: '30px',
    padding: '20px',
    border: '1px solid #ddd',
    borderRadius: '5px',
    backgroundColor: '#f9f9f9',
  },
  form: {
    display: 'grid',
    gridTemplateColumns: 'repeat(2, 1fr)',
    gap: '20px',
  },
  formGroup: {
    display: 'flex',
    flexDirection: 'column',
    gap: '5px',
  },
  select: {
    padding: '8px',
    borderRadius: '4px',
    border: '1px solid #ddd',
  },
  readOnlyInput: {
    padding: '8px',
    borderRadius: '4px',
    border: '1px solid #ddd',
    backgroundColor: '#f0f0f0',
    cursor: 'not-allowed',
  },
  buttonGroup: {
    display: 'flex',
    gap: '10px',
  },
  submitButton: {
    padding: '10px',
    backgroundColor: '#4CAF50',
    color: 'white',
    border: 'none',
    borderRadius: '4px',
    cursor: 'pointer',
    fontSize: '16px',
    fontWeight: 'bold',
    transition: 'background-color 0.3s',
    flex: 1,
  },
  cancelButton: {
    padding: '10px',
    backgroundColor: '#f44336',
    color: 'white',
    border: 'none',
    borderRadius: '4px',
    cursor: 'pointer',
    fontSize: '16px',
    fontWeight: 'bold',
    transition: 'background-color 0.3s',
    flex: 1,
  },
  editButton: {
    padding: '5px 10px',
    backgroundColor: '#2196F3',
    color: 'white',
    border: 'none',
    borderRadius: '4px',
    cursor: 'pointer',
    marginRight: '5px',
    fontSize: '14px',
  },
  deleteButton: {
    padding: '5px 10px',
    backgroundColor: '#f44336',
    color: 'white',
    border: 'none',
    borderRadius: '4px',
    cursor: 'pointer',
    fontSize: '14px',
  },
  tableContainer: {
    marginTop: '20px',
  },
  tableWrapper: {
    overflowX: 'auto',
    boxShadow: '0 0 10px rgba(0,0,0,0.1)',
    borderRadius: '5px',
  },
  table: {
    width: '100%',
    borderCollapse: 'collapse',
    backgroundColor: 'white',
  },
  th: {
    backgroundColor: '#f2f2f2',
    padding: '12px 15px',
    textAlign: 'left',
    borderBottom: '1px solid #ddd',
  },
  td: {
    padding: '12px 15px',
    borderBottom: '1px solid #ddd',
    verticalAlign: 'top',
  },
  loading: {
    padding: '20px',
    textAlign: 'center',
    color: '#666',
  },
  noData: {
    padding: '20px',
    textAlign: 'center',
    color: '#666',
    border: '1px dashed #ddd',
    borderRadius: '5px',
  },
  errorAlert: {
    backgroundColor: '#ffebee',
    color: '#d32f2f',
    padding: '15px',
    borderRadius: '4px',
    marginBottom: '20px',
    display: 'flex',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  successAlert: {
    backgroundColor: '#e8f5e9',
    color: '#2e7d32',
    padding: '15px',
    borderRadius: '4px',
    marginBottom: '20px',
    display: 'flex',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  alertCloseButton: {
    background: 'none',
    border: 'none',
    color: 'inherit',
    fontSize: '20px',
    cursor: 'pointer',
    padding: '0',
    marginLeft: '10px',
  },
};

export default Services;