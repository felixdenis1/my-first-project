import React from 'react';
import { Link, Outlet, useNavigate } from 'react-router-dom';

const Dashboard = ({ setIsAuthenticated }) => {
  const navigate = useNavigate();

  const handleLogout = () => {
    localStorage.removeItem('token');
    setIsAuthenticated(false);
    navigate('/login');
  };

  return (
    <div style={styles.container}>
      <header style={styles.header}>
        <h1>SmartPark CWSMS</h1>
        <button onClick={handleLogout} style={styles.logoutButton}>
          Logout
        </button>
      </header>
      <nav style={styles.nav}>
        <Link to="/" style={styles.navLink}>
          Services
        </Link>
        <Link to="/cars" style={styles.navLink}>
          Cars
        </Link>
        <Link to="/reports" style={styles.navLink}>
          Reports
        </Link>
      </nav>
      <main style={styles.main}>
        <Outlet />
      </main>
    </div>
  );
};

const styles = {
  container: {
    display: 'flex',
    flexDirection: 'column',
    minHeight: '100vh',
  },
  header: {
    backgroundColor: '#333',
    color: 'white',
    padding: '1rem',
    display: 'flex',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  logoutButton: {
    padding: '0.5rem 1rem',
    backgroundColor: '#dc3545',
    color: 'white',
    border: 'none',
    borderRadius: '4px',
    cursor: 'pointer',
  },
  nav: {
    backgroundColor: '#f8f9fa',
    padding: '1rem',
    display: 'flex',
    gap: '1rem',
  },
  navLink: {
    textDecoration: 'none',
    color: '#333',
    padding: '0.5rem 1rem',
    borderRadius: '4px',
    backgroundColor: '#e9ecef',
  },
  main: {
    flex: 1,
    padding: '1rem',
  },
};

export default Dashboard;