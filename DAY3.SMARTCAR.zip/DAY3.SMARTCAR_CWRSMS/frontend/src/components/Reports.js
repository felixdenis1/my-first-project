import React, { useState, useEffect } from 'react';
import axios from 'axios';

const Reports = () => {
  const [reportData, setReportData] = useState([]);
  const [dateFilter, setDateFilter] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState(null);

  const fetchReportData = async () => {
    setIsLoading(true);
    setError(null);
    try {
      const token = localStorage.getItem('token');
      const response = await axios.get('http://localhost:5000/api/reports/daily', {
        headers: { Authorization: `Bearer ${token}` },
        params: { date: dateFilter || new Date().toISOString().split('T')[0] }
      });
      
      // Ensure we always have an array
      const data = Array.isArray(response.data) ? response.data : [];
      setReportData(data);
      
      if (data.length === 0) {
        setError('No data available for the selected date');
      }
    } catch (error) {
      console.error('Error fetching report:', error);
      setError('Failed to load report data');
      setReportData([]);
    } finally {
      setIsLoading(false);
    }
  };

  const handleDownload = async () => {
    try {
      setIsLoading(true);
      const token = localStorage.getItem('token');
      const response = await axios.get('http://localhost:5000/api/reports/download', {
        headers: { Authorization: `Bearer ${token}` },
        responseType: 'blob',
        params: { date: dateFilter || new Date().toISOString().split('T')[0] }
      });
      
      const url = window.URL.createObjectURL(new Blob([response.data]));
      const link = document.createElement('a');
      link.href = url;
      const filename = response.headers['content-disposition']?.split('filename=')[1] || 
                     `carwash_report_${dateFilter || new Date().toISOString().split('T')[0]}.csv`;
      link.setAttribute('download', filename);
      document.body.appendChild(link);
      link.click();
      link.remove();
    } catch (error) {
      console.error('Error downloading report:', error);
      setError('Failed to download report');
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    fetchReportData();
  }, [dateFilter]);

  const formatDate = (dateString) => {
    const options = { 
      year: 'numeric', 
      month: 'short', 
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    };
    return new Date(dateString).toLocaleString('en-US', options);
  };

  return (
    <div style={styles.container}>
      <h2 style={styles.header}>Daily Reports</h2>
      
      <div style={styles.filterContainer}>
        <label style={styles.filterLabel}>Filter by Date: </label>
        <input
          type="date"
          value={dateFilter}
          onChange={(e) => setDateFilter(e.target.value)}
          style={styles.dateInput}
          max={new Date().toISOString().split('T')[0]}
        />
        <button 
          onClick={handleDownload}
          style={styles.downloadButton}
          disabled={isLoading || reportData.length === 0}
        >
          {isLoading ? 'Processing...' : 'Download CSV'}
        </button>
      </div>

      {error && (
        <div style={styles.errorMessage}>
          {error}
        </div>
      )}

      {isLoading ? (
        <div style={styles.loadingContainer}>
          <p>Loading report data...</p>
        </div>
      ) : (
        <div style={styles.tableContainer}>
          <table style={styles.table}>
            <thead>
              <tr>
                <th style={styles.th}>Plate Number</th>
                <th style={styles.th}>Package</th>
                <th style={styles.th}>Description</th>
                <th style={styles.th}>Amount (RWF)</th>
                <th style={styles.th}>Service Date</th>
              </tr>
            </thead>
            <tbody>
              {reportData.length > 0 ? (
                reportData.map((item, index) => (
                  <tr key={index}>
                    <td style={styles.td}>{item.plate_number}</td>
                    <td style={styles.td}>{item.package_name}</td>
                    <td style={styles.td}>{item.package_description}</td>
                    <td style={styles.td}>{item.amount_paid?.toLocaleString()}</td>
                    <td style={styles.td}>{formatDate(item.service_date)}</td>
                  </tr>
                ))
              ) : !error && (
                <tr>
                  <td colSpan="5" style={styles.noDataCell}>
                    No data available
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
};

const styles = {
  container: {
    padding: '20px',
    maxWidth: '1200px',
    margin: '0 auto',
    fontFamily: 'Arial, sans-serif',
  },
  header: {
    color: '#333',
    marginBottom: '20px',
    borderBottom: '2px solid #4CAF50',
    paddingBottom: '10px',
  },
  filterContainer: {
    margin: '20px 0',
    display: 'flex',
    alignItems: 'center',
    gap: '15px',
    flexWrap: 'wrap',
  },
  filterLabel: {
    fontWeight: 'bold',
    minWidth: '100px',
  },
  dateInput: {
    padding: '8px',
    borderRadius: '4px',
    border: '1px solid #ddd',
    fontSize: '14px',
  },
  downloadButton: {
    padding: '8px 16px',
    backgroundColor: '#4CAF50',
    color: 'white',
    border: 'none',
    borderRadius: '4px',
    cursor: 'pointer',
    marginLeft: 'auto',
    transition: 'background-color 0.3s',
    fontSize: '14px',
    fontWeight: 'bold',
  },
  downloadButtonDisabled: {
    backgroundColor: '#cccccc',
    cursor: 'not-allowed',
  },
  tableContainer: {
    marginTop: '20px',
    overflowX: 'auto',
    boxShadow: '0 0 10px rgba(0,0,0,0.1)',
    borderRadius: '8px',
  },
  table: {
    width: '100%',
    borderCollapse: 'collapse',
    fontSize: '14px',
  },
  th: {
    backgroundColor: '#4CAF50',
    color: 'white',
    padding: '12px',
    textAlign: 'left',
    fontWeight: 'bold',
  },
  td: {
    padding: '12px',
    borderBottom: '1px solid #ddd',
  },
  noDataCell: {
    textAlign: 'center',
    padding: '20px',
    color: '#666',
  },
  errorMessage: {
    color: '#d32f2f',
    backgroundColor: '#fdecea',
    padding: '10px',
    borderRadius: '4px',
    margin: '10px 0',
    borderLeft: '4px solid #d32f2f',
  },
  loadingContainer: {
    display: 'flex',
    justifyContent: 'center',
    alignItems: 'center',
    padding: '20px',
  },
};

export default Reports;