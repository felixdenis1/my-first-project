import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { useNavigate } from 'react-router-dom';

const Cars = () => {
  const navigate = useNavigate();
  const [cars, setCars] = useState([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');
  const [formData, setFormData] = useState({
    plate_number: '',
    car_type: '',
    car_size: '',
    driver_name: '',
    phone_number: '',
  });

  // Configure axios instance
  const api = axios.create({
    baseURL: 'http://localhost:5000/api',
    headers: {
      'Content-Type': 'application/json'
    }
  });

  // Add request interceptor for auth token
  api.interceptors.request.use(config => {
    const token = localStorage.getItem('token');
    if (token) {
      config.headers.Authorization = `Bearer ${token}`;
    } else {
      navigate('/login'); // Redirect to login if no token
    }
    return config;
  });

  // Add response interceptor for error handling
  api.interceptors.response.use(
    response => response,
    error => {
      if (error.response?.status === 401) {
        localStorage.removeItem('token');
        navigate('/login');
      }
      return Promise.reject(error);
    }
  );

  useEffect(() => {
    fetchCars();
  }, []);

  const fetchCars = async () => {
    try {
      setLoading(true);
      const response = await api.get('/cars');
      setCars(response.data);
      setError('');
      setLoading(false);
    } catch (error) {
      handleApiError(error, 'Failed to fetch cars');
      setLoading(false);
    }
  };

  const handleChange = (e) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError('');
    setSuccess('');
    
    try {
      await api.post('/cars', formData);
      setSuccess('Car added successfully!');
      fetchCars();
      setFormData({
        plate_number: '',
        car_type: '',
        car_size: '',
        driver_name: '',
        phone_number: '',
      });
      
      // Clear success message after 3 seconds
      setTimeout(() => setSuccess(''), 3000);
    } catch (error) {
      handleApiError(error, 'Failed to add car');
    }
  };

  const handleDelete = async (plateNumber) => {
    if (window.confirm('Are you sure you want to delete this car?')) {
      try {
        await api.delete(`/cars/${plateNumber}`);
        setSuccess('Car deleted successfully!');
        fetchCars();
        setTimeout(() => setSuccess(''), 3000);
      } catch (error) {
        handleApiError(error, 'Failed to delete car');
      }
    }
  };

  const handleApiError = (error, defaultMessage) => {
    console.error(error);
    if (error.response?.data?.error) {
      setError(error.response.data.error);
    } else {
      setError(defaultMessage);
    }
    
    // Clear error after 5 seconds
    setTimeout(() => setError(''), 5000);
  };

  // Styles
  const styles = {
    container: {
      padding: '20px',
      maxWidth: '1200px',
      margin: '0 auto',
      fontFamily: 'Arial, sans-serif'
    },
    header: {
      color: '#333',
      borderBottom: '2px solid #4CAF50',
      paddingBottom: '10px',
      marginBottom: '20px'
    },
    formContainer: {
      marginBottom: '30px',
      padding: '20px',
      border: '1px solid #ddd',
      borderRadius: '5px',
      backgroundColor: '#f9f9f9',
      boxShadow: '0 2px 4px rgba(0,0,0,0.1)'
    },
    formTitle: {
      color: '#444',
      marginTop: '0'
    },
    form: {
      display: 'grid',
      gridTemplateColumns: 'repeat(auto-fit, minmax(200px, 1fr))',
      gap: '15px',
    },
    formGroup: {
      display: 'flex',
      flexDirection: 'column',
      marginBottom: '15px'
    },
    label: {
      marginBottom: '5px',
      fontWeight: 'bold',
      color: '#555'
    },
    input: {
      padding: '10px',
      borderRadius: '4px',
      border: '1px solid #ddd',
      fontSize: '16px'
    },
    select: {
      padding: '10px',
      borderRadius: '4px',
      border: '1px solid #ddd',
      fontSize: '16px',
      backgroundColor: 'white'
    },
    submitButton: {
      padding: '12px',
      backgroundColor: '#4CAF50',
      color: 'white',
      border: 'none',
      borderRadius: '4px',
      cursor: 'pointer',
      fontSize: '16px',
      fontWeight: 'bold',
      gridColumn: '1 / -1',
      marginTop: '10px',
      transition: 'background-color 0.3s',
      ':hover': {
        backgroundColor: '#45a049'
      }
    },
    message: {
      padding: '10px',
      borderRadius: '4px',
      margin: '15px 0',
      textAlign: 'center'
    },
    error: {
      backgroundColor: '#ffebee',
      color: '#d32f2f',
      border: '1px solid #ef9a9a'
    },
    success: {
      backgroundColor: '#e8f5e9',
      color: '#2e7d32',
      border: '1px solid #a5d6a7'
    },
    tableContainer: {
      marginTop: '30px',
      overflowX: 'auto',
      boxShadow: '0 1px 3px rgba(0,0,0,0.1)'
    },
    table: {
      width: '100%',
      borderCollapse: 'collapse',
      marginTop: '15px'
    },
    th: {
      backgroundColor: '#4CAF50',
      color: 'white',
      padding: '12px',
      textAlign: 'left',
      borderBottom: '2px solid #ddd'
    },
    td: {
      padding: '12px',
      textAlign: 'left',
      borderBottom: '1px solid #ddd'
    },
    trHover: {
      ':hover': {
        backgroundColor: '#f5f5f5'
      }
    },
    actionButton: {
      padding: '6px 12px',
      margin: '0 5px',
      borderRadius: '4px',
      cursor: 'pointer',
      border: 'none',
      fontWeight: 'bold'
    },
    editButton: {
      backgroundColor: '#2196F3',
      color: 'white'
    },
    deleteButton: {
      backgroundColor: '#f44336',
      color: 'white'
    },
    loading: {
      textAlign: 'center',
      padding: '20px',
      color: '#666'
    }
  };

  return (
    <div style={styles.container}>
      <h2 style={styles.header}>Car Management</h2>
      
      {error && (
        <div style={{ ...styles.message, ...styles.error }}>
          {error}
        </div>
      )}
      
      {success && (
        <div style={{ ...styles.message, ...styles.success }}>
          {success}
        </div>
      )}

      <div style={styles.formContainer}>
        <h3 style={styles.formTitle}>Add New Car</h3>
        <form onSubmit={handleSubmit} style={styles.form}>
          <div style={styles.formGroup}>
            <label style={styles.label}>Plate Number:</label>
            <input
              type="text"
              name="plate_number"
              value={formData.plate_number}
              onChange={handleChange}
              style={styles.input}
              required
              pattern="[A-Za-z0-9 ]+"
              title="Only letters, numbers and spaces allowed"
            />
          </div>
          <div style={styles.formGroup}>
            <label style={styles.label}>Car Type:</label>
            <input
              type="text"
              name="car_type"
              value={formData.car_type}
              onChange={handleChange}
              style={styles.input}
              required
            />
          </div>
          <div style={styles.formGroup}>
            <label style={styles.label}>Car Size:</label>
            <select
              name="car_size"
              value={formData.car_size}
              onChange={handleChange}
              style={styles.select}
              required
            >
              <option value="">Select size</option>
              <option value="Small">Small</option>
              <option value="Medium">Medium</option>
              <option value="Large">Large</option>
            </select>
          </div>
          <div style={styles.formGroup}>
            <label style={styles.label}>Driver Name:</label>
            <input
              type="text"
              name="driver_name"
              value={formData.driver_name}
              onChange={handleChange}
              style={styles.input}
              required
            />
          </div>
          <div style={styles.formGroup}>
            <label style={styles.label}>Phone Number:</label>
            <input
              type="tel"
              name="phone_number"
              value={formData.phone_number}
              onChange={handleChange}
              style={styles.input}
              required
              pattern="[0-9]{10,15}"
              title="10-15 digit phone number"
            />
          </div>
          <button type="submit" style={styles.submitButton}>
            Add Car
          </button>
        </form>
      </div>

      <div style={styles.tableContainer}>
        <h3>Registered Cars</h3>
        {loading ? (
          <div style={styles.loading}>Loading cars...</div>
        ) : (
          <table style={styles.table}>
            <thead>
              <tr>
                <th style={styles.th}>Plate Number</th>
                <th style={styles.th}>Car Type</th>
                <th style={styles.th}>Car Size</th>
                <th style={styles.th}>Driver Name</th>
                <th style={styles.th}>Phone Number</th>
                <th style={styles.th}>Actions</th>
              </tr>
            </thead>
            <tbody>
              {cars.map((car) => (
                <tr key={car.plate_number} style={styles.trHover}>
                  <td style={styles.td}>{car.plate_number}</td>
                  <td style={styles.td}>{car.car_type}</td>
                  <td style={styles.td}>{car.car_size}</td>
                  <td style={styles.td}>{car.driver_name}</td>
                  <td style={styles.td}>{car.phone_number}</td>
                  <td style={styles.td}>
                    <button 
                      style={{ ...styles.actionButton, ...styles.editButton }}
                      onClick={() => {/* Add edit functionality */}}
                    >
                      Edit
                    </button>
                    <button 
                      style={{ ...styles.actionButton, ...styles.deleteButton }}
                      onClick={() => handleDelete(car.plate_number)}
                    >
                      Delete
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </div>
    </div>
  );
};

export default Cars;