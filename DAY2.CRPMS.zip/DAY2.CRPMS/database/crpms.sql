CREATE DATABASE IF NOT EXISTS crpms;
USE crpms;

CREATE TABLE Services (
    ServiceCode VARCHAR(10) PRIMARY KEY,
    ServiceName VARCHAR(100),
    ServicePrice DECIMAL(10, 2)
);

CREATE TABLE Car (
    PlateNumber VARCHAR(20) PRIMARY KEY,
    Type VARCHAR(50),
    Model VARCHAR(50),
    ManufacturingYear INT,
    DriverPhone VARCHAR(20),
    MechanicName VARCHAR(100)
);

CREATE TABLE ServiceRecord (
    RecordNumber INT AUTO_INCREMENT PRIMARY KEY,
    PlateNumber VARCHAR(20),
    ServiceCode VARCHAR(10),
    ServiceDate DATE,
    FOREIGN KEY (PlateNumber) REFERENCES Car(PlateNumber),
    FOREIGN KEY (ServiceCode) REFERENCES Services(ServiceCode)
);

CREATE TABLE Payment (
    PaymentNumber INT AUTO_INCREMENT PRIMARY KEY,
    RecordNumber INT,
    AmountPaid DECIMAL(10, 2),
    PaymentDate DATE,
    FOREIGN KEY (RecordNumber) REFERENCES ServiceRecord(RecordNumber)
);