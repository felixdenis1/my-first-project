import { useState, useEffect } from 'react';
import axios from 'axios';

const Services = () => {
    const [services, setServices] = useState([]);

    useEffect(() => {
        fetchServices();
    }, []);

    const fetchServices = async () => {
        try {
            const res = await axios.get('http://localhost:5000/services');
            setServices(res.data);
        } catch (err) {
            console.error(err);
        }
    };

    return (
        <div>
            <h2 className="text-2xl font-bold mb-4">Services</h2>
            
            <div className="bg-white rounded shadow overflow-hidden">
                <h3 className="text-xl font-semibold p-4 bg-gray-100">Available Services</h3>
                <div className="overflow-x-auto">
                    <table className="min-w-full">
                        <thead className="bg-gray-50">
                            <tr>
                                <th className="px-6 py-3 text-left">Code</th>
                                <th className="px-6 py-3 text-left">Service Name</th>
                                <th className="px-6 py-3 text-left">Price (RWF)</th>
                            </tr>
                        </thead>
                        <tbody className="divide-y divide-gray-200">
                            {services.map((service) => (
                                <tr key={service.ServiceCode}>
                                    <td className="px-6 py-4">{service.ServiceCode}</td>
                                    <td className="px-6 py-4">{service.ServiceName}</td>
                                    <td className="px-6 py-4">{service.ServicePrice.toLocaleString()}</td>
                                </tr>
                            ))}
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    );
};

export default Services;