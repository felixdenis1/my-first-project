import { useState, useEffect } from 'react';
import axios from 'axios';

const ServiceRecords = () => {
    const [records, setRecords] = useState([]);
    const [cars, setCars] = useState([]);
    const [services, setServices] = useState([]);
    const [formData, setFormData] = useState({
        ServiceDate: '',
        PlateNumber: '',
        ServiceCode: ''
    });
    const [editingId, setEditingId] = useState(null);
    const [isEditing, setIsEditing] = useState(false);

    useEffect(() => {
        fetchRecords();
        fetchCars();
        fetchServices();
    }, []);

    const fetchRecords = async () => {
        try {
            const res = await axios.get('http://localhost:5000/service-records');
            setRecords(res.data);
        } catch (err) {
            console.error(err);
        }
    };

    const fetchCars = async () => {
        try {
            const res = await axios.get('http://localhost:5000/cars');
            setCars(res.data);
        } catch (err) {
            console.error(err);
        }
    };

    const fetchServices = async () => {
        try {
            const res = await axios.get('http://localhost:5000/services');
            setServices(res.data);
        } catch (err) {
            console.error(err);
        }
    };

    const handleChange = (e) => {
        setFormData({ ...formData, [e.target.name]: e.target.value });
    };

    const handleSubmit = async (e) => {
        e.preventDefault();
        try {
            if (isEditing) {
                await axios.put(`http://localhost:5000/service-records/${editingId}`, formData);
            } else {
                await axios.post('http://localhost:5000/service-records', formData);
            }
            fetchRecords();
            resetForm();
        } catch (err) {
            console.error(err);
        }
    };

    const handleEdit = (record) => {
        setFormData({
            ServiceDate: record.ServiceDate.split('T')[0], // Format date for input
            PlateNumber: record.PlateNumber,
            ServiceCode: record.ServiceCode
        });
        setEditingId(record.RecordNumber);
        setIsEditing(true);
    };

    const handleDelete = async (id) => {
        if (window.confirm('Are you sure you want to delete this record?')) {
            try {
                await axios.delete(`http://localhost:5000/service-records/${id}`);
                fetchRecords();
            } catch (err) {
                console.error(err);
            }
        }
    };

    const resetForm = () => {
        setFormData({
            ServiceDate: '',
            PlateNumber: '',
            ServiceCode: ''
        });
        setEditingId(null);
        setIsEditing(false);
    };

    return (
        <div>
            <h2 className="text-2xl font-bold mb-4">Service Records</h2>
            
            <form onSubmit={handleSubmit} className="mb-8 bg-white p-4 rounded shadow">
                <h3 className="text-xl font-semibold mb-3">
                    {isEditing ? 'Edit Service Record' : 'Add New Service Record'}
                </h3>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                    <div>
                        <label className="block mb-1">Service Date</label>
                        <input
                            type="date"
                            name="ServiceDate"
                            value={formData.ServiceDate}
                            onChange={handleChange}
                            className="w-full p-2 border rounded"
                            required
                        />
                    </div>
                    <div>
                        <label className="block mb-1">Car</label>
                        <select
                            name="PlateNumber"
                            value={formData.PlateNumber}
                            onChange={handleChange}
                            className="w-full p-2 border rounded"
                            required
                        >
                            <option value="">Select Car</option>
                            {cars.map(car => (
                                <option key={car.PlateNumber} value={car.PlateNumber}>
                                    {car.PlateNumber} - {car.Model}
                                </option>
                            ))}
                        </select>
                    </div>
                    <div>
                        <label className="block mb-1">Service</label>
                        <select
                            name="ServiceCode"
                            value={formData.ServiceCode}
                            onChange={handleChange}
                            className="w-full p-2 border rounded"
                            required
                        >
                            <option value="">Select Service</option>
                            {services.map(service => (
                                <option key={service.ServiceCode} value={service.ServiceCode}>
                                    {service.ServiceName} ({service.ServicePrice.toLocaleString()} RWF)
                                </option>
                            ))}
                        </select>
                    </div>
                </div>
                <div className="mt-4 space-x-2">
                    <button 
                        type="submit" 
                        className="bg-blue-600 text-white px-4 py-2 rounded hover:bg-blue-700"
                    >
                        {isEditing ? 'Update Record' : 'Add Record'}
                    </button>
                    {isEditing && (
                        <button
                            type="button"
                            onClick={resetForm}
                            className="bg-gray-500 text-white px-4 py-2 rounded hover:bg-gray-600"
                        >
                            Cancel
                        </button>
                    )}
                </div>
            </form>

            <div className="bg-white rounded shadow overflow-hidden">
                <h3 className="text-xl font-semibold p-4 bg-gray-100">Service Records</h3>
                <div className="overflow-x-auto">
                    <table className="min-w-full">
                        <thead className="bg-gray-50">
                            <tr>
                                <th className="px-6 py-3 text-left">Record #</th>
                                <th className="px-6 py-3 text-left">Date</th>
                                <th className="px-6 py-3 text-left">Car Plate</th>
                                <th className="px-6 py-3 text-left">Car Model</th>
                                <th className="px-6 py-3 text-left">Service</th>
                                <th className="px-6 py-3 text-left">Price (RWF)</th>
                                <th className="px-6 py-3 text-left">Actions</th>
                            </tr>
                        </thead>
                        <tbody className="divide-y divide-gray-200">
                            {records.map((record) => (
                                <tr key={record.RecordNumber}>
                                    <td className="px-6 py-4">{record.RecordNumber}</td>
                                    <td className="px-6 py-4">{new Date(record.ServiceDate).toLocaleDateString()}</td>
                                    <td className="px-6 py-4">{record.PlateNumber}</td>
                                    <td className="px-6 py-4">{record.Model}</td>
                                    <td className="px-6 py-4">{record.ServiceName}</td>
                                    <td className="px-6 py-4">{record.ServicePrice.toLocaleString()}</td>
                                    <td className="px-6 py-4 space-x-2">
                                        <button
                                            onClick={() => handleEdit(record)}
                                            className="text-blue-600 hover:text-blue-800"
                                        >
                                            Edit
                                        </button>
                                        <button
                                            onClick={() => handleDelete(record.RecordNumber)}
                                            className="text-red-600 hover:text-red-800"
                                        >
                                            Delete
                                        </button>
                                    </td>
                                </tr>
                            ))}
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    );
};

export default ServiceRecords;