import { useState, useEffect } from 'react';
import axios from 'axios';

const Payments = () => {
    const [payments, setPayments] = useState([]);
    const [records, setRecords] = useState([]);
    const [formData, setFormData] = useState({
        AmountPaid: '',
        PaymentDate: '',
        RecordNumber: ''
    });
    const [editingId, setEditingId] = useState(null);
    const [isEditing, setIsEditing] = useState(false);

    useEffect(() => {
        fetchPayments();
        fetchServiceRecords();
    }, []);

    const fetchPayments = async () => {
        try {
            const res = await axios.get('http://localhost:5000/payments');
            setPayments(res.data);
        } catch (err) {
            console.error(err);
        }
    };

    const fetchServiceRecords = async () => {
        try {
            const res = await axios.get('http://localhost:5000/service-records');
            setRecords(res.data);
        } catch (err) {
            console.error(err);
        }
    };

    const handleChange = (e) => {
        setFormData({ ...formData, [e.target.name]: e.target.value });
    };

    const handleSubmit = async (e) => {
        e.preventDefault();
        try {
            if (isEditing) {
                await axios.put(`http://localhost:5000/payments/${editingId}`, formData);
            } else {
                await axios.post('http://localhost:5000/payments', formData);
            }
            fetchPayments();
            resetForm();
        } catch (err) {
            console.error(err);
        }
    };

    const handleEdit = (payment) => {
        setFormData({
            AmountPaid: payment.AmountPaid,
            PaymentDate: payment.PaymentDate.split('T')[0],
            RecordNumber: payment.RecordNumber
        });
        setEditingId(payment.PaymentNumber);
        setIsEditing(true);
    };

    const handleDelete = async (id) => {
        if (window.confirm('Are you sure you want to delete this payment?')) {
            try {
                await axios.delete(`http://localhost:5000/payments/${id}`);
                fetchPayments();
            } catch (err) {
                console.error(err);
            }
        }
    };

    const resetForm = () => {
        setFormData({
            AmountPaid: '',
            PaymentDate: '',
            RecordNumber: ''
        });
        setEditingId(null);
        setIsEditing(false);
    };

    return (
        <div>
            <h2 className="text-2xl font-bold mb-4">Payments</h2>
            
            <form onSubmit={handleSubmit} className="mb-8 bg-white p-4 rounded shadow">
                <h3 className="text-xl font-semibold mb-3">
                    {isEditing ? 'Edit Payment Record' : 'Record New Payment'}
                </h3>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                    <div>
                        <label className="block mb-1">Payment Date</label>
                        <input
                            type="date"
                            name="PaymentDate"
                            value={formData.PaymentDate}
                            onChange={handleChange}
                            className="w-full p-2 border rounded"
                            required
                        />
                    </div>
                    <div>
                        <label className="block mb-1">Service Record</label>
                        <select
                            name="RecordNumber"
                            value={formData.RecordNumber}
                            onChange={handleChange}
                            className="w-full p-2 border rounded"
                            required
                        >
                            <option value="">Select Service Record</option>
                            {records.map(record => (
                                <option key={record.RecordNumber} value={record.RecordNumber}>
                                    #{record.RecordNumber} - {record.PlateNumber} ({record.ServiceName})
                                </option>
                            ))}
                        </select>
                    </div>
                    <div>
                        <label className="block mb-1">Amount Paid (RWF)</label>
                        <input
                            type="number"
                            name="AmountPaid"
                            value={formData.AmountPaid}
                            onChange={handleChange}
                            className="w-full p-2 border rounded"
                            required
                        />
                    </div>
                </div>
                <div className="mt-4 space-x-2">
                    <button 
                        type="submit" 
                        className="bg-blue-600 text-white px-4 py-2 rounded hover:bg-blue-700"
                    >
                        {isEditing ? 'Update Payment' : 'Record Payment'}
                    </button>
                    {isEditing && (
                        <button
                            type="button"
                            onClick={resetForm}
                            className="bg-gray-500 text-white px-4 py-2 rounded hover:bg-gray-600"
                        >
                            Cancel
                        </button>
                    )}
                </div>
            </form>

            <div className="bg-white rounded shadow overflow-hidden">
                <h3 className="text-xl font-semibold p-4 bg-gray-100">Payment History</h3>
                <div className="overflow-x-auto">
                    <table className="min-w-full">
                        <thead className="bg-gray-50">
                            <tr>
                                <th className="px-6 py-3 text-left">Payment #</th>
                                <th className="px-6 py-3 text-left">Date</th>
                                <th className="px-6 py-3 text-left">Amount (RWF)</th>
                                <th className="px-6 py-3 text-left">Service Record</th>
                                <th className="px-6 py-3 text-left">Car Plate</th>
                                <th className="px-6 py-3 text-left">Service</th>
                                <th className="px-6 py-3 text-left">Actions</th>
                            </tr>
                        </thead>
                        <tbody className="divide-y divide-gray-200">
                            {payments.map((payment) => (
                                <tr key={payment.PaymentNumber}>
                                    <td className="px-6 py-4">{payment.PaymentNumber}</td>
                                    <td className="px-6 py-4">{new Date(payment.PaymentDate).toLocaleDateString()}</td>
                                    <td className="px-6 py-4">{payment.AmountPaid.toLocaleString()}</td>
                                    <td className="px-6 py-4">#{payment.RecordNumber}</td>
                                    <td className="px-6 py-4">{payment.PlateNumber}</td>
                                    <td className="px-6 py-4">{payment.ServiceName}</td>
                                    <td className="px-6 py-4 space-x-2">
                                        <button
                                            onClick={() => handleEdit(payment)}
                                            className="text-blue-600 hover:text-blue-800"
                                        >
                                            Edit
                                        </button>
                                        <button
                                            onClick={() => handleDelete(payment.PaymentNumber)}
                                            className="text-red-600 hover:text-red-800"
                                        >
                                            Delete
                                        </button>
                                    </td>
                                </tr>
                            ))}
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    );
};

export default Payments;