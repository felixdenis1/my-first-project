import { useState, useEffect } from 'react';
import axios from 'axios';

const Reports = () => {
    const [summary, setSummary] = useState(null);
    const [payments, setPayments] = useState([]);

    useEffect(() => {
        fetchSummary();
        fetchRecentPayments();
    }, []);

    const fetchSummary = async () => {
        try {
            const res = await axios.get('http://localhost:5000/reports/summary');
            setSummary(res.data);
        } catch (err) {
            console.error(err);
        }
    };

    const fetchRecentPayments = async () => {
        try {
            const res = await axios.get('http://localhost:5000/payments');
            setPayments(res.data.slice(0, 5)); // Show only 5 most recent payments
        } catch (err) {
            console.error(err);
        }
    };

    if (!summary) return <div>Loading...</div>;

    return (
        <div>
            <h2 className="text-2xl font-bold mb-4">Reports</h2>
            
            <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-8">
                <div className="bg-white p-4 rounded shadow">
                    <h3 className="text-lg font-semibold mb-2">Total Revenue</h3>
                    <p className="text-2xl font-bold text-green-600">
                        {summary.totalRevenue ? summary.totalRevenue.toLocaleString() : 0} RWF
                    </p>
                </div>
                <div className="bg-white p-4 rounded shadow">
                    <h3 className="text-lg font-semibold mb-2">Total Payments</h3>
                    <p className="text-2xl font-bold text-blue-600">
                        {summary.totalPayments}
                    </p>
                </div>
                <div className="bg-white p-4 rounded shadow">
                    <h3 className="text-lg font-semibold mb-2">Cars Serviced</h3>
                    <p className="text-2xl font-bold text-purple-600">
                        {summary.totalCarsServiced}
                    </p>
                </div>
                <div className="bg-white p-4 rounded shadow">
                    <h3 className="text-lg font-semibold mb-2">Services Provided</h3>
                    <p className="text-2xl font-bold text-orange-600">
                        {summary.totalServices}
                    </p>
                </div>
            </div>

            <div className="bg-white rounded shadow overflow-hidden mb-8">
                <h3 className="text-xl font-semibold p-4 bg-gray-100">Recent Payments</h3>
                <div className="overflow-x-auto">
                    <table className="min-w-full">
                        <thead className="bg-gray-50">
                            <tr>
                                <th className="px-6 py-3 text-left">Payment #</th>
                                <th className="px-6 py-3 text-left">Date</th>
                                <th className="px-6 py-3 text-left">Amount (RWF)</th>
                                <th className="px-6 py-3 text-left">Car Plate</th>
                                <th className="px-6 py-3 text-left">Service</th>
                            </tr>
                        </thead>
                        <tbody className="divide-y divide-gray-200">
                            {payments.map((payment) => (
                                <tr key={payment.PaymentNumber}>
                                    <td className="px-6 py-4">{payment.PaymentNumber}</td>
                                    <td className="px-6 py-4">{new Date(payment.PaymentDate).toLocaleDateString()}</td>
                                    <td className="px-6 py-4">{payment.AmountPaid.toLocaleString()}</td>
                                    <td className="px-6 py-4">{payment.PlateNumber}</td>
                                    <td className="px-6 py-4">{payment.ServiceName}</td>
                                </tr>
                            ))}
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    );
};

export default Reports;