import { useState, useEffect } from 'react';
import axios from 'axios';

const Cars = () => {
    const [cars, setCars] = useState([]);
    const [formData, setFormData] = useState({
        PlateNumber: '',
        Type: '',
        Model: '',
        ManufacturingYear: '',
        DriverPhone: '',
        MechanicName: ''
    });

    useEffect(() => {
        fetchCars();
    }, []);

    const fetchCars = async () => {
        try {
            const res = await axios.get('http://localhost:5000/cars');
            setCars(res.data);
        } catch (err) {
            console.error(err);
        }
    };

    const handleChange = (e) => {
        setFormData({ ...formData, [e.target.name]: e.target.value });
    };

    const handleSubmit = async (e) => {
        e.preventDefault();
        try {
            await axios.post('http://localhost:5000/cars', formData);
            fetchCars();
            setFormData({
                PlateNumber: '',
                Type: '',
                Model: '',
                ManufacturingYear: '',
                DriverPhone: '',
                MechanicName: ''
            });
        } catch (err) {
            console.error(err);
        }
    };

    return (
        <div>
            <h2 className="text-2xl font-bold mb-4">Cars</h2>
            
            <form onSubmit={handleSubmit} className="mb-8 bg-white p-4 rounded shadow">
                <h3 className="text-xl font-semibold mb-3">Add New Car</h3>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                        <label className="block mb-1">Plate Number</label>
                        <input
                            type="text"
                            name="PlateNumber"
                            value={formData.PlateNumber}
                            onChange={handleChange}
                            className="w-full p-2 border rounded"
                            required
                        />
                    </div>
                    <div>
                        <label className="block mb-1">Type</label>
                        <input
                            type="text"
                            name="Type"
                            value={formData.Type}
                            onChange={handleChange}
                            className="w-full p-2 border rounded"
                            required
                        />
                    </div>
                    <div>
                        <label className="block mb-1">Model</label>
                        <input
                            type="text"
                            name="Model"
                            value={formData.Model}
                            onChange={handleChange}
                            className="w-full p-2 border rounded"
                            required
                        />
                    </div>
                    <div>
                        <label className="block mb-1">Manufacturing Year</label>
                        <input
                            type="number"
                            name="ManufacturingYear"
                            value={formData.ManufacturingYear}
                            onChange={handleChange}
                            className="w-full p-2 border rounded"
                            required
                        />
                    </div>
                    <div>
                        <label className="block mb-1">Driver Phone</label>
                        <input
                            type="text"
                            name="DriverPhone"
                            value={formData.DriverPhone}
                            onChange={handleChange}
                            className="w-full p-2 border rounded"
                            required
                        />
                    </div>
                    <div>
                        <label className="block mb-1">Mechanic Name</label>
                        <input
                            type="text"
                            name="MechanicName"
                            value={formData.MechanicName}
                            onChange={handleChange}
                            className="w-full p-2 border rounded"
                            required
                        />
                    </div>
                </div>
                <button type="submit" className="mt-4 bg-blue-600 text-white px-4 py-2 rounded hover:bg-blue-700">
                    Add Car
                </button>
            </form>

            <div className="bg-white rounded shadow overflow-hidden">
                <h3 className="text-xl font-semibold p-4 bg-gray-100">Car List</h3>
                <div className="overflow-x-auto">
                    <table className="min-w-full">
                        <thead className="bg-gray-50">
                            <tr>
                                <th className="px-6 py-3 text-left">Plate Number</th>
                                <th className="px-6 py-3 text-left">Type</th>
                                <th className="px-6 py-3 text-left">Model</th>
                                <th className="px-6 py-3 text-left">Year</th>
                                <th className="px-6 py-3 text-left">Driver Phone</th>
                                <th className="px-6 py-3 text-left">Mechanic</th>
                            </tr>
                        </thead>
                        <tbody className="divide-y divide-gray-200">
                            {cars.map((car) => (
                                <tr key={car.PlateNumber}>
                                    <td className="px-6 py-4">{car.PlateNumber}</td>
                                    <td className="px-6 py-4">{car.Type}</td>
                                    <td className="px-6 py-4">{car.Model}</td>
                                    <td className="px-6 py-4">{car.ManufacturingYear}</td>
                                    <td className="px-6 py-4">{car.DriverPhone}</td>
                                    <td className="px-6 py-4">{car.MechanicName}</td>
                                </tr>
                            ))}
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    );
};

export default Cars;