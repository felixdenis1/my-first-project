// App.js
import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import { useState, useEffect } from 'react';
import Cars from './components/Cars';
import Services from './components/Services';
import ServiceRecords from './components/ServiceRecords';
import Payments from './components/Payments';
import Reports from './components/Reports';
import Home from './components/Home';
import Login from './components/Login';

function App() {
    const [user, setUser] = useState(null);

    useEffect(() => {
        const loggedInUser = localStorage.getItem('user');
        if (loggedInUser) {
            setUser(JSON.parse(loggedInUser));
        }
    }, []);

    const handleLogout = () => {
        localStorage.removeItem('user');
        setUser(null);
    };

    if (!user) {
        return (
            <Router>
                <Routes>
                    <Route path="/" element={<Login setUser={setUser} />} />
                    <Route path="*" element={<Navigate to="/" />} />
                </Routes>
            </Router>
        );
    }

    return (
        <Router>
            <Routes>
                <Route path="/" element={<Home handleLogout={handleLogout} />} />
                <Route path="/cars" element={<Cars handleLogout={handleLogout} />} />
                <Route path="/services" element={<Services handleLogout={handleLogout} />} />
                <Route path="/service-records" element={<ServiceRecords handleLogout={handleLogout} />} />
                <Route path="/payments" element={<Payments handleLogout={handleLogout} />} />
                <Route path="/reports" element={<Reports handleLogout={handleLogout} />} />
                <Route path="*" element={<Navigate to="/" />} />
            </Routes>
        </Router>
    );
}

export default App;