const express = require('express');
const mysql = require('mysql2');
const cors = require('cors');

const app = express();
app.use(cors());
app.use(express.json());

// Database connection
const db = mysql.createConnection({
    host: 'localhost',
    user: 'root', // replace with your MySQL username
    password: 'Felix300512#', // replace with your MySQL password
    database: 'CRPMS'
});

db.connect(err => {
    if (err) {
        console.error('Database connection failed:', err.stack);
        return;
    }
    console.log('Connected to database.');
});

// Add this near the top with other requires
const bcrypt = require('bcryptjs');

// Simple user database (for demonstration only)
const users = [
    {
        id: 1,
        username: 'admin',
        // Password is "1234" hashed
        password: '$2a$10$V6rSUrJZq.ZKGDZ1NoI8b.8v8nN9zYTUvD.7Z7QJz5J5z5X5X5X5X'
    }
];

// Login endpoint
app.post('/login', (req, res) => {
    const { username, password } = req.body;
    const user = users.find(u => u.username === username);
    
    if (!user) {
        return res.status(401).send('Invalid username or password');
    }

    if (password !== "1234") {
        return res.status(401).send('Invalid username or password');
    
        }
        res.json({ message: 'Login successful', user: { id: user.id, username: user.username } });
    });



app.post('/cars', (req, res) => {
    const { PlateNumber, Type, Model, ManufacturingYear, DriverPhone, MechanicName } = req.body;
    const query = 'INSERT INTO Car SET ?';
    db.query(query, { PlateNumber, Type, Model, ManufacturingYear, DriverPhone, MechanicName }, (err, result) => {
        if (err) return res.status(500).send(err);
        res.status(201).send('Car added successfully');
    });
});

app.get('/cars', (req, res) => {
    db.query('SELECT * FROM Car', (err, results) => {
        if (err) return res.status(500).send(err);
        res.json(results);
    });
});

// SERVICES endpoints
app.get('/services', (req, res) => {
    db.query('SELECT * FROM Services', (err, results) => {
        if (err) return res.status(500).send(err);
        res.json(results);
    });
});

// SERVICE RECORD endpoints
app.post('/service-records', (req, res) => {
    const { ServiceDate, PlateNumber, ServiceCode } = req.body;
    const query = 'INSERT INTO ServiceRecord SET ?';
    db.query(query, { ServiceDate, PlateNumber, ServiceCode }, (err, result) => {
        if (err) return res.status(500).send(err);
        res.status(201).send('Service record added successfully');
    });
});

app.get('/service-records', (req, res) => {
    const query = `
        SELECT sr.RecordNumber, sr.ServiceDate, c.PlateNumber, c.Type, c.Model, 
               s.ServiceName, s.ServicePrice 
        FROM ServiceRecord sr
        JOIN Car c ON sr.PlateNumber = c.PlateNumber
        JOIN Services s ON sr.ServiceCode = s.ServiceCode
    `;
    db.query(query, (err, results) => {
        if (err) return res.status(500).send(err);
        res.json(results);
    });
});

// PAYMENT endpoints
app.post('/payments', (req, res) => {
    const { AmountPaid, PaymentDate, RecordNumber } = req.body;
    const query = 'INSERT INTO Payment SET ?';
    db.query(query, { AmountPaid, PaymentDate, RecordNumber }, (err, result) => {
        if (err) {
            console.error("Payment Insert Error:", err); // <-- log it here
            return res.status(500).send(err);
        }
        res.status(201).send('Payment added successfully');
    });
});


app.get('/payments', (req, res) => {
    const query = `
        SELECT p.PaymentNumber, p.AmountPaid, p.PaymentDate, 
               sr.RecordNumber, sr.ServiceDate, c.PlateNumber, c.Model,
               s.ServiceName, s.ServicePrice
        FROM Payment p
        JOIN ServiceRecord sr ON p.RecordNumber = sr.RecordNumber
        JOIN Car c ON sr.PlateNumber = c.PlateNumber
        JOIN Services s ON sr.ServiceCode = s.ServiceCode
    `;
    db.query(query, (err, results) => {
        if (err) return res.status(500).send(err);
        res.json(results);
    });
});

// REPORTS
app.get('/reports/summary', (req, res) => {
    const query = `
        SELECT 
            COUNT(DISTINCT p.PaymentNumber) as totalPayments,
            SUM(p.AmountPaid) as totalRevenue,
            COUNT(DISTINCT c.PlateNumber) as totalCarsServiced,
            COUNT(DISTINCT sr.RecordNumber) as totalServices
        FROM Payment p
        JOIN ServiceRecord sr ON p.RecordNumber = sr.RecordNumber
        JOIN Car c ON sr.PlateNumber = c.PlateNumber
    `;
    db.query(query, (err, results) => {
        if (err) return res.status(500).send(err);
        res.json(results[0]);
    });
});

// Update service record
app.put('/service-records/:id', (req, res) => {
    const { id } = req.params;
    const { ServiceDate, PlateNumber, ServiceCode } = req.body;
    const query = 'UPDATE ServiceRecord SET ServiceDate = ?, PlateNumber = ?, ServiceCode = ? WHERE RecordNumber = ?';
    db.query(query, [ServiceDate, PlateNumber, ServiceCode, id], (err, result) => {
        if (err) return res.status(500).send(err);
        res.send('Service record updated successfully');
    });
});

// Delete service record
app.delete('/service-records/:id', (req, res) => {
    const { id } = req.params;
    const query = 'DELETE FROM ServiceRecord WHERE RecordNumber = ?';
    db.query(query, [id], (err, result) => {
        if (err) return res.status(500).send(err);
        res.send('Service record deleted successfully');
    });
});

// Update payment
app.put('/payments/:id', (req, res) => {
    const { id } = req.params;
    const { AmountPaid, PaymentDate, RecordNumber } = req.body;
    const query = 'UPDATE Payment SET AmountPaid = ?, PaymentDate = ?, RecordNumber = ? WHERE PaymentNumber = ?';
    db.query(query, [AmountPaid, PaymentDate, RecordNumber, id], (err, result) => {
        if (err) return res.status(500).send(err);
        res.send('Payment updated successfully');
    });
});

// Delete payment
app.delete('/payments/:id', (req, res) => {
    const { id } = req.params;
    const query = 'DELETE FROM Payment WHERE PaymentNumber = ?';
    db.query(query, [id], (err, result) => {
        if (err) return res.status(500).send(err);
        res.send('Payment deleted successfully');
    });
});

const PORT = 5000;
app.listen(PORT, () => {
    console.log(`Server running on port ${PORT}`);
});