const express = require('express');
const mysql = require('mysql2');
const session = require('express-session');
const cors = require('cors');

const app = express();

// Middleware
app.use(cors());
app.use(express.json());
app.use(session({
    secret: 'camellia_secret',
    resave: false,
    saveUninitialized: true
}));

// DB connection
const db = mysql.createConnection({  
    host: 'localhost',
    user: 'root',
    password: 'Felix300512#',
    database: 'Camellia'
});

db.connect((err) => {
    if (err) {
        console.error('MySQL connection error:', err);
        process.exit(1);
    }
    console.log('MySQL connected!');
});


// Registration endpoint
app.post('/api/register', (req, res) => {
  const { UserName, Password } = req.body;

  if (!UserName || !Password) {
    return res.status(400).json({ error: 'Username and password are required' });
  }

  const sql = 'INSERT INTO Users (UserName, Password) VALUES (?, ?)';
  db.query(sql, [UserName, Password], (err, result) => {
    if (err) {
      console.error('Error inserting user:', err);
      return res.status(500).json({ error: 'Database error' });
    }
    res.status(201).json({ message: 'User registered successfully' });
  });
});

// Helper function for error handling
const handleDbError = (err, res) => {
    console.error('Database error:', err);
    
    if (err.code === 'ER_DUP_ENTRY') {
        return res.status(409).send('Duplicate entry');
    }
    if (err.code === 'ER_NO_REFERENCED_ROW_2') {
        return res.status(400).send('Invalid reference');
    }
    
    res.status(500).send('Database operation failed');
};

// User Registration
app.post('/api/register', (req, res) => {
    const { UserName, Password } = req.body;
    if (!UserName || !Password) {
        return res.status(400).send('Username and password required');
    }
    
    db.query('INSERT INTO Users (UserName, Password) VALUES (?, ?)', 
        [UserName, Password], 
        (err) => {
            if (err) return handleDbError(err, res);
            res.send('User registered');
        }
    );
});

// Login
app.post('/api/login', (req, res) => {
    const { UserName, Password } = req.body;
    db.query('SELECT * FROM Users WHERE UserName = ? AND Password = ?', 
        [UserName, Password], 
        (err, results) => {
            if (err) return handleDbError(err, res);
            if (results.length > 0) {
                req.session.user = results[0];
                res.send({ message: 'Logged in' });
            } else {
                res.status(401).send('Invalid credentials');
            }
        }
    );
});

// Posts CRUD
app.get('/api/posts', (req, res) => {
    db.query('SELECT * FROM Post', (err, rows) => {
        if (err) return handleDbError(err, res);
        res.send(rows);
    });
});

app.post('/api/posts', (req, res) => {
    if (!req.body.PostName) {
        return res.status(400).send('PostName required');
    }
    
    db.query('INSERT INTO Post (PostName) VALUES (?)', 
        [req.body.PostName], 
        (err) => {
            if (err) return handleDbError(err, res);
            res.send('Post added');
        }
    );
});

// Fixed Candidate Endpoint
app.post('/api/candidates', (req, res) => {
    const c = req.body;
    
    // Required field validation
    if (!c.CandidateNationalId) {
        return res.status(400).send('CandidateNationalId is required');
    }
    
    // Convert numeric fields
    const postId = c.PostId ? parseInt(c.PostId) : null;
    const marks = c.Marks ? parseInt(c.Marks) : null;
    
    // Date validation
    const isValidDate = (d) => !isNaN(new Date(d).getTime());
    if (c.DateOfBirth && !isValidDate(c.DateOfBirth)) {
        return res.status(400).send('Invalid DateOfBirth format');
    }
    if (c.ExamDate && !isValidDate(c.ExamDate)) {
        return res.status(400).send('Invalid ExamDate format');
    }

    db.query(
        `INSERT INTO CandidateResult 
        (CandidateNationalId, FirstName, LastName, Gender, DateOfBirth, PostId, ExamDate, PhoneNumber, Marks) 
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)`,
        [
            c.CandidateNationalId,
            c.FirstName || null,
            c.LastName || null,
            c.Gender || null,
            c.DateOfBirth || null,
            postId,
            c.ExamDate || null,
            c.PhoneNumber || null,
            marks
        ],
        (err) => {
            if (err) return handleDbError(err, res);
            res.send('Candidate added');
        }
    );
});

// Other endpoints remain the same as your original
app.get('/api/candidates', (req, res) => {
    db.query('SELECT * FROM CandidateResult', (err, rows) => {
        if (err) return handleDbError(err, res);
        res.send(rows);
    });
});

app.get('/api/report/:postId', (req, res) => {
    db.query('SELECT * FROM CandidateResult WHERE PostId = ? ORDER BY Marks DESC', 
        [req.params.postId], 
        (err, rows) => {
            if (err) return handleDbError(err, res);
            res.send(rows);
        }
    );
});

//delete api
app.delete('/api/posts/:id', (req, res) => {
    const postId = req.params.id;
    const sql = 'DELETE FROM Post WHERE PostId = ?';
  
    db.query(sql, [postId], (err, result) => {
      if (err) {
        console.error('Error deleting post:', err);
        return res.status(500).json({ error: 'Database error' });
      }
      if (result.affectedRows === 0) {
        return res.status(404).json({ error: 'Post not found' });
      }
      res.status(200).json({ message: 'Post deleted successfully' });
    });
  });
  

app.get('/api/results', (req, res) => {
    const sql = `
      SELECT 
        cr.CandidateNationalId,
        cr.FirstName,
        cr.LastName,
        cr.Marks,
        p.PostName
      FROM CandidateResult cr
      JOIN Post p ON cr.PostId = p.PostId
      ORDER BY p.PostName ASC, cr.Marks DESC
    `;
  
    db.query(sql, (err, results) => {
      if (err) return res.status(500).json({ error: err.message });
      res.json(results);
    });
  });
  app.put('/api/candidates/:id', (req, res) => {
    const candidateId = req.params.id;
    const {
      FirstName,
      LastName,
      Gender,
      DateOfBirth,
      PostId,
      ExamDate,
      PhoneNumber,
      Marks
    } = req.body;
  
    const sql = `
      UPDATE CandidateResult
      SET FirstName = ?, LastName = ?, Gender = ?, DateOfBirth = ?, PostId = ?, ExamDate = ?, PhoneNumber = ?, Marks = ?
      WHERE CandidateNationalId = ?
    `;
  
    db.query(
      sql,
      [FirstName, LastName, Gender, DateOfBirth, PostId, ExamDate, PhoneNumber, Marks, candidateId],
      (err, result) => {
        if (err) {
          console.error('Error updating candidate:', err);
          return res.status(500).json({ error: 'Database error' });
        }
        if (result.affectedRows === 0) {
          return res.status(404).json({ error: 'Candidate not found' });
        }
        res.status(200).json({ message: 'Candidate updated successfully' });
      }
    );
  });
  
  

app.listen(5007, () => console.log('Server running on http://localhost:5007'));