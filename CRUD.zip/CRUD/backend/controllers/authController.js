
const db = require('../config/db');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');

exports.register = (req, res) => {
    const { UserName, Password } = req.body;
    const hashedPassword = bcrypt.hashSync(Password, 10);
    db.query('INSERT INTO Users (UserName, Password) VALUES (?, ?)', [UserName, hashedPassword], (err, result) => {
        if (err) return res.status(500).json(err);
        res.status(200).json({ message: 'User registered successfully' });
    });
};

exports.login = (req, res) => {
    const { UserName, Password } = req.body;
    db.query('SELECT * FROM Users WHERE UserName = ?', [UserName], (err, results) => {
        if (err || results.length === 0) return res.status(401).json({ message: 'Invalid credentials' });
        const user = results[0];
        const isValid = bcrypt.compareSync(Password, user.Password);
        if (!isValid) return res.status(401).json({ message: 'Invalid credentials' });

        const token = jwt.sign({ id: user.UserId }, process.env.JWT_SECRET, { expiresIn: '1h' });
        res.json({ token });
    });
};
