
const db = require('../config/db');

exports.addCandidate = (req, res) => {
    const data = req.body;
    const sql = 'INSERT INTO CandidateResult SET ?';
    db.query(sql, data, (err) => {
        if (err) return res.status(500).json(err);
        res.json({ message: 'Candidate added successfully' });
    });
};

exports.getCandidates = (req, res) => {
    db.query('SELECT * FROM CandidateResult', (err, results) => {
        if (err) return res.status(500).json(err);
        res.json(results);
    });
};

exports.getReport = (req, res) => {
    const { postId } = req.params;
    db.query('SELECT * FROM CandidateResult WHERE PostId = ? ORDER BY Marks DESC', [postId], (err, results) => {
        if (err) return res.status(500).json(err);
        res.json(results);
    });
};
