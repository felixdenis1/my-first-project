
const db = require('../config/db');

exports.getPosts = (req, res) => {
    db.query('SELECT * FROM Post', (err, results) => {
        if (err) return res.status(500).json(err);
        res.json(results);
    });
};

exports.createPost = (req, res) => {
    const { PostName } = req.body;
    db.query('INSERT INTO Post (PostName) VALUES (?)', [PostName], (err) => {
        if (err) return res.status(500).json(err);
        res.json({ message: 'Post added successfully' });
    });
};

exports.updatePost = (req, res) => {
    const { id } = req.params;
    const { PostName } = req.body;
    db.query('UPDATE Post SET PostName = ? WHERE PostId = ?', [PostName, id], (err) => {
        if (err) return res.status(500).json(err);
        res.json({ message: 'Post updated successfully' });
    });
};

exports.deletePost = (req, res) => {
    const { id } = req.params;
    db.query('DELETE FROM Post WHERE PostId = ?', [id], (err) => {
        if (err) return res.status(500).json(err);
        res.json({ message: 'Post deleted successfully' });
    });
};
