
const express = require('express');
const router = express.Router();
const { addCandidate, getCandidates, getReport } = require('../controllers/candidateController');

router.post('/', addCandidate);
router.get('/', getCandidates);
router.get('/report/:postId', getReport);

module.exports = router;
