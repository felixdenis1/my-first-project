// Register.js
import { Navigate, useNavigate } from 'react-router-dom';
import React, { useState } from 'react';
import axios from 'axios';
import './App.css'; 

export default function Register() {
  const [form, setForm] = useState({ UserName: '', Password: '' });

  const handleChange = (e) => {
    const { name, value } = e.target;
    setForm({ ...form, [name]: value });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!form.UserName || !form.Password) {
      alert('Please fill in both fields');
      return;
    }

    try {
      const res = await axios.post('http://localhost:5007/api/register', form);
      alert(res.data.message);
      Navigate('/Login');
      setForm({ UserName: '', Password: '' });
    } catch (err) {
      console.error('Registration error:', err);
      alert('Registration failed. Please try again.');
    }
  };

  return (
    <div className="register-container">
        
      <h2>Manager Registration</h2>
      <form className="register-form" onSubmit={handleSubmit}>
        <input
          type="text"
          name="UserName"
          placeholder="Username"
          value={form.UserName}
          onChange={handleChange}
        />
        <input
          type="password"
          name="Password"
          placeholder="Password"
          value={form.Password}
          onChange={handleChange}
        />
        <button type="submit">Register</button> <a href="Login">login here</a>
      </form>
    </div>
  );
}
