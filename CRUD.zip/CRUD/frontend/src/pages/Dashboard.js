
import React from 'react';
import { Link } from 'react-router-dom';
import './App.css'; 

function Dashboard() {
  return (
    <div>
    <div class="dash1" >
     <div class="dash2"> <h1>Dashboard</h1></div>
      <nav>
        <ul>
       <div class="down">  <li><Link to="/posts">Manage Posts</Link></li>
          <li><Link to="/candidates">Manage Candidates</Link></li>
          <li><Link to="/report">View Report</Link></li>
          <li><Link to="/Login">Login</Link></li>
          
          </div> 
        </ul>
      </nav>
    </div></div>
  );
}

export default Dashboard;
