import React, { useEffect, useState } from 'react';
import axios from 'axios';

export default function Posts() {
  const [posts, setPosts] = useState([]);
  const [name, setName] = useState('');

  const fetchPosts = async () => {
    const res = await axios.get('http://localhost:5007/api/posts');
    setPosts(res.data);
  };

  const addPost = async () => {
    if (!name.trim()) return alert("Post name is required");
    await axios.post('http://localhost:5007/api/posts', { PostName: name });
    setName('');
    fetchPosts();
  };

  const deletePost = async (id) => {
    const confirm = window.confirm("Are you sure you want to delete this post?");
    
    if (!confirm) return;
    await axios.delete(`http://localhost:5007/api/posts/${id}`);
    fetchPosts();
  };

  useEffect(() => {
    fetchPosts();
  }, []);

  return (
    <div>
      <h2>Posts</h2>
      <input
        placeholder="Post name"
        value={name}
        onChange={(e) => setName(e.target.value)}
      />
      <button onClick={addPost}>Add</button>
      <ul>
        {posts.map((p) => (
          <li key={p.PostId}>
            {p.PostName}{" "}
            <button onClick={() => deletePost(p.PostId)} style={{ color: 'red' }}>
              Delete
            </button>
          </li>
        ))}
      </ul>
    </div>
  );
}
