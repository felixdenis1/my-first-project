import React, { useState, useEffect } from 'react';
import axios from 'axios';

export default function Candidates() {
  const [form, setForm] = useState({
    CandidateNationalId: '',
    FirstName: '',
    LastName: '',
    Gender: '',
    DateOfBirth: '',
    PostId: '',
    ExamDate: '',
    PhoneNumber: '',
    Marks: ''
  });

  const [posts, setPosts] = useState([]);

  useEffect(() => {
    axios.get('http://localhost:5007/api/posts')
      .then(res => setPosts(res.data))
      .catch(err => console.error("Error fetching posts:", err));
  }, []);

  const handleChange = (e) => {
    const { name, value } = e.target;
    setForm({ ...form, [name]: value });
  };

  const handleSubmit = async () => {
    const data = {
      ...form,
      PostId: parseInt(form.PostId),
      Marks: parseInt(form.Marks)
    };

    // Validate fields
    for (const key in data) {
      if (!data[key] && data[key] !== 0) {
        alert(`${key} is required`);
        return;
      }
    }

    try {
      await axios.post('http://localhost:5007/api/candidates', data);
      alert('Candidate added successfully');
      setForm({
        CandidateNationalId: '',
        FirstName: '',
        LastName: '',
        Gender: '',
        DateOfBirth: '',
        PostId: '',
        ExamDate: '',
        PhoneNumber: '',
        Marks: ''
      });
    } catch (err) {
      console.error(err);
      alert('Failed to add candidate. See console for details.');
    }
  };
  const updateCandidate = async (candidateId, updatedData) => {
    try {
      await axios.put(`http://localhost:5007/api/candidates/${candidateId}`, updatedData);
      // Refresh the candidate list or update the state accordingly
    } catch (error) {
      console.error('Error updating candidate:', error);
      // Handle error (e.g., display an error message to the user)
    }
  };
  const deleteCandidate = async (candidateId) => {
    try {
      await axios.delete(`http://localhost:5007/api/candidates/${candidateId}`);
      // Refresh the candidate list or update the state accordingly
    } catch (error) {
      console.error('Error deleting candidate:', error);
      // Handle error (e.g., display an error message to the user)
    }
  };
    

  return (
    <div>
      <h2>Add Candidate</h2>
      <input
        type="text"
        name="CandidateNationalId"
        placeholder="National ID"
        value={form.CandidateNationalId}
        onChange={handleChange}
      />
      <input
        type="text"
        name="FirstName"
        placeholder="First Name"
        value={form.FirstName}
        onChange={handleChange}
      />
      <input
        type="text"
        name="LastName"
        placeholder="Last Name"
        value={form.LastName}
        onChange={handleChange}
      />
      <select name="Gender" value={form.Gender} onChange={handleChange}>
        <option value="">Select Gender</option>
        <option value="Male">Male</option>
        <option value="Female">Female</option>
      </select>
     Date of birth: <input
        type="date"
        name="DateOfBirth"
        placeholder="Date of Birth"
        value={form.DateOfBirth}
        onChange={handleChange}
      />
      <select name="PostId" value={form.PostId} onChange={handleChange}>
        <option value="">Select Post</option>
        {posts.map(p => (
          <option key={p.PostId} value={p.PostId}>{p.PostName}</option>
        ))}
      </select>
     exam date: <input
        type="date"
        name="ExamDate"
        placeholder="Exam Date"
        value={form.ExamDate}
        onChange={handleChange}
      />
      <input
        type="text"
        name="PhoneNumber"
        placeholder="Phone Number"
        value={form.PhoneNumber}
        onChange={handleChange}
      />
      <input
        type="number"
        name="Marks"
        placeholder="Marks (out of 100)"
        value={form.Marks}
        onChange={handleChange}
      />
      <br /><br />
      <button onClick={handleSubmit}>Submit</button>
    </div>
  );
}
