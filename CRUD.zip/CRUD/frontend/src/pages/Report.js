import React, { useEffect, useState } from 'react';
import axios from 'axios';

export default function Report() {
  const [results, setResults] = useState([]);
  const [editingId, setEditingId] = useState(null);
  const [editFormData, setEditFormData] = useState({
    CandidateNationalId: '',
    FirstName: '',
    LastName: '',
    Marks: '',
    PostName: ''
  });

  useEffect(() => {
    fetchResults();
  }, []);

  const fetchResults = () => {
    axios.get('http://localhost:5007/api/results')
      .then(res => setResults(res.data))
      .catch(err => console.error(err));
  };

  const grouped = results.reduce((acc, cur) => {
    acc[cur.PostName] = acc[cur.PostName] || [];
    acc[cur.PostName].push(cur);
    return acc;
  }, {});

  const handleDelete = (id) => {
    if (window.confirm('Are you sure you want to delete this record?')) {
      axios.delete(`http://localhost:5007/api/results/${id}`)
        .then(() => {
          fetchResults(); // Refresh the list after deletion
          alert('Record deleted successfully');
        })
        .catch(err => console.error(err));
    }
  };

  const handleEditClick = (candidate) => {
    setEditingId(candidate.CandidateNationalId);
    setEditFormData({
      CandidateNationalId: candidate.CandidateNationalId,
      FirstName: candidate.FirstName,
      LastName: candidate.LastName,
      Marks: candidate.Marks,
      PostName: candidate.PostName
    });
  };

  const handleEditFormChange = (e) => {
    const { name, value } = e.target;
    setEditFormData(prev => ({
      ...prev,
      [name]: value
    }));
  };

  const handleEditSubmit = (e) => {
    e.preventDefault();
    axios.put(`http://localhost:5007/api/results/${editingId}`, editFormData)
      .then(() => {
        fetchResults(); // Refresh the list after update
        setEditingId(null);
        alert('Record updated successfully');
      })
      .catch(err => console.error(err));
  };

  const handleCancelEdit = () => {
    setEditingId(null);
  };

  return (
    <div>
      <h2>Candidate Results Report</h2>
      {Object.entries(grouped).map(([post, candidates]) => (
        <div key={post}>
          <h3>{post}</h3>
          <table border="1" cellPadding="9">
            <thead>
              <tr>
                <th>National ID</th>
                <th>Name</th>
                <th>Marks</th>
                <th>Actions</th>
              </tr>
            </thead>
            <tbody>
              {candidates.map(c => (
                <React.Fragment key={c.CandidateNationalId}>
                  {editingId === c.CandidateNationalId ? (
                    <tr>
                      <td colSpan="4">
                        <form onSubmit={handleEditSubmit}>
                          <table>
                            <tr>
                              <td>
                                <input
                                  type="text"
                                  name="CandidateNationalId"
                                  value={editFormData.CandidateNationalId}
                                  onChange={handleEditFormChange}
                                  disabled
                                />
                              </td>
                              <td>
                                <input
                                  type="text"
                                  name="FirstName"
                                  value={editFormData.FirstName}
                                  onChange={handleEditFormChange}
                                  required
                                />
                                <input
                                  type="text"
                                  name="LastName"
                                  value={editFormData.LastName}
                                  onChange={handleEditFormChange}
                                  required
                                />
                              </td>
                              <td>
                                <input
                                  type="number"
                                  name="Marks"
                                  value={editFormData.Marks}
                                  onChange={handleEditFormChange}
                                  required
                                />
                              </td>
                              <td>
                                <button type="submit">Save</button>
                                <button type="button" onClick={handleCancelEdit}>Cancel</button>
                              </td>
                            </tr>
                          </table>
                        </form>
                      </td>
                    </tr>
                  ) : (
                    <tr>
                      <td>{c.CandidateNationalId}</td>
                      <td>{c.FirstName} {c.LastName}</td>
                      <td>{c.Marks}</td>
                      <td>
                        <button onClick={() => handleEditClick(c)}>Edit</button>
                        <button onClick={() => handleDelete(c.CandidateNationalId)}>Delete</button>
                      </td>
                    </tr>
                  )}
                </React.Fragment>
              ))}
            </tbody>
          </table>
        </div>
      ))}
    </div>
  );
}