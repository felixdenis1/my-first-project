import React from 'react';
import { Link } from 'react-router-dom';

export default function Navbar() {
  return (
    <nav>
      <Link to="/posts">Posts</Link> | <Link to="/candidates">Candidates</Link> | <Link to="/report">Report</Link>
    </nav>
  );
}