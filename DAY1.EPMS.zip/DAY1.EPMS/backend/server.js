const express = require("express");
const mysql = require("mysql2");
const cors = require("cors");
const session = require("express-session");
const bodyParser = require("body-parser");

const app = express();
const PORT = 5000;

app.use(cors({
  origin: "http://localhost:3000",
  credentials: true,
}));
app.use(bodyParser.json());
app.use(session({
  secret: "secret",
  resave: false,
  saveUninitialized: true,
}));

// MySQL Connection Pool
const pool = mysql.createPool({
  host: "localhost",
  user: "root",
  password: "Felix300512#",
  database: "EPMS",
  waitForConnections: true,
  connectionLimit: 10,
  queueLimit: 0,
}).promise();

// 🔍 Test connection
pool.query('SELECT 1')
  .then(() => console.log('✅ MySQL Connected'))
  .catch(err => console.error('❌ MySQL Connection Failed:', err));

// --- EMPLOYEE ---
app.post('/employees', async (req, res) => {
  const payload = req.body;
  
  if (!payload.EmployeeNumber) {
    return res.status(400).json({ message: 'EmployeeNumber is required' });
  }
  if (!payload.DepartmentCode) {
    return res.status(400).json({ message: 'DepartmentCode is required' });
  }

  try {
    const [results] = await pool.query('INSERT INTO Employee SET ?', payload);
    res.json({ message: 'Employee created', results });
  } catch (err) {
    console.error("SQL Error:", err);
    if (err.code === 'ER_DUP_ENTRY') {
      return res.status(400).json({ message: 'Employee number already exists' });
    }
    if (err.code === 'ER_NO_REFERENCED_ROW_2') {
      return res.status(400).json({ message: 'Department code does not exist' });
    }
    res.status(500).json({ message: 'Database error', error: err });
  }
});

app.get('/employees', async (req, res) => {
  try {
    const [results] = await pool.query('SELECT * FROM Employee');
    res.json(results);
  } catch (err) {
    res.status(500).send(err);
  }
});

// --- SALARY ---
// Create salary
app.post('/salaries', async (req, res) => {
  const { EmployeeNumber, GrossSalary, TotalDeduction, NetSalary, Month } = req.body;
  
  // Basic validation
  if (!EmployeeNumber || !Month) {
    return res.status(400).json({ error: "EmployeeNumber and Month are required" });
  }

  try {
    const [result] = await pool.query(
      'INSERT INTO Salary (EmployeeNumber, GrossSalary, TotalDeduction, NetSalary, Month) VALUES (?, ?, ?, ?, ?)',
      [EmployeeNumber, GrossSalary, TotalDeduction, NetSalary, Month]
    );
    res.status(201).json({ 
      message: 'Salary record created successfully',
      salaryId: result.insertId 
    });
  } catch (err) {
    console.error("Salary creation error:", err);
    if (err.code === 'ER_NO_REFERENCED_ROW_2') {
      return res.status(400).json({ error: "EmployeeNumber does not exist" });
    }
    res.status(500).json({ error: "Failed to create salary record" });
  }
});

// Get all salaries
app.get('/salaries', async (req, res) => {
  try {
    const [results] = await pool.query(`
      SELECT s.*, e.FirstName, e.LastName 
      FROM Salary s
      LEFT JOIN Employee e ON s.EmployeeNumber = e.EmployeeNumber
      ORDER BY s.Month DESC, s.SalaryID DESC
    `);
    res.json(results);
  } catch (err) {
    console.error("Failed to fetch salaries:", err);
    res.status(500).json({ error: "Failed to load salary records" });
  }
});

// Get single salary
app.get('/salaries/:id', async (req, res) => {
  try {
    const [results] = await pool.query('SELECT * FROM Salary WHERE SalaryID = ?', [req.params.id]);
    if (results.length === 0) {
      return res.status(404).json({ error: 'Salary record not found' });
    }
    res.json(results[0]);
  } catch (err) {
    console.error("Failed to fetch salary:", err);
    res.status(500).json({ error: "Failed to load salary record" });
  }
});

// Update salary
app.put('/salaries/:id', async (req, res) => {
  const { EmployeeNumber, GrossSalary, TotalDeduction, NetSalary, Month } = req.body;
  
  if (!EmployeeNumber || !Month) {
    return res.status(400).json({ error: "EmployeeNumber and Month are required" });
  }

  try {
    const [result] = await pool.query(
      `UPDATE Salary 
       SET EmployeeNumber = ?, GrossSalary = ?, TotalDeduction = ?, NetSalary = ?, Month = ?
       WHERE SalaryID = ?`,
      [EmployeeNumber, GrossSalary, TotalDeduction, NetSalary, Month, req.params.id]
    );
    
    if (result.affectedRows === 0) {
      return res.status(404).json({ error: 'Salary record not found' });
    }
    
    res.json({ message: 'Salary record updated successfully' });
  } catch (err) {
    console.error("Salary update error:", err);
    if (err.code === 'ER_NO_REFERENCED_ROW_2') {
      return res.status(400).json({ error: "EmployeeNumber does not exist" });
    }
    res.status(500).json({ error: "Failed to update salary record" });
  }
});

// Delete salary
app.delete('/salaries/:id', async (req, res) => {
  try {
    const [result] = await pool.query('DELETE FROM Salary WHERE SalaryID = ?', [req.params.id]);
    
    if (result.affectedRows === 0) {
      return res.status(404).json({ error: 'Salary record not found' });
    }
    
    res.json({ message: 'Salary record deleted successfully' });
  } catch (err) {
    console.error("Salary deletion error:", err);
    res.status(500).json({ error: "Failed to delete salary record" });
  }
});

// --- REPORT ---
app.get('/reports', async (req, res) => {
  const sql = `
    SELECT E.FirstName, E.LastName, S.Month, S.GrossSalary, S.TotalDeduction, S.NetSalary
    FROM Salary S
    JOIN Employee E ON E.EmployeeNumber = S.EmployeeNumber
  `;
  try {
    const [results] = await pool.query(sql);
    res.json(results);
  } catch (err) {
    res.status(500).send(err);
  }
});

// --- REGISTRATION ---
app.post('/register', async (req, res) => {
  const { username, password } = req.body;
  try {
    const [results] = await pool.query(
      'INSERT INTO users (username, password) VALUES (?, ?)',
      [username, password]
    );
    res.json({ success: true, userId: results.insertId });
  } catch (err) {
    res.status(500).json({ success: false, message: 'Username might already exist' });
  }
});

// --- LOGIN ---
app.post('/login', async (req, res) => {
  const { username, password } = req.body;
  try {
    const [results] = await pool.query(
      'SELECT * FROM users WHERE username = ? AND password = ?', 
      [username, password]
    );
    if (results.length) {
      res.json({ success: true, user: results[0] });
    } else {
      res.status(401).json({ success: false, message: 'Invalid credentials' });
    }
  } catch (err) {
    res.status(500).send(err);
  }
});

// --- DEPARTMENTS ---
app.get('/departments', async (req, res) => {
  try {
    const [results] = await pool.query('SELECT DepartmentCode, DepartmentName FROM Department');
    res.json(results);
  } catch (err) {
    console.error("Failed to fetch departments:", err);
    res.status(500).json({ message: 'Failed to load departments' });
  }
});

app.post("/department", async (req, res) => {
  const { DepartmentCode, DepartmentName, GrossSalary, TotalDeduction } = req.body;
  
  if (!DepartmentCode || !DepartmentName) {
    return res.status(400).json({ error: "Department code and name are required" });
  }

  try {
    await pool.query(
      "INSERT INTO Department (DepartmentCode, DepartmentName, GrossSalary, TotalDeduction) VALUES (?, ?, ?, ?)", 
      [DepartmentCode, DepartmentName, GrossSalary || null, TotalDeduction || null]
    );
    res.json({ message: "Department added successfully" });
  } catch (err) {
    console.error(err);
    if (err.code === 'ER_DUP_ENTRY') {
      res.status(400).json({ error: "Department code already exists" });
    } else {
      res.status(500).json({ error: "Failed to add department" });
    }
  }
});

// ===== START SERVER =====
app.listen(PORT, () => {
  console.log(`✅ Server running at http://localhost:${PORT}`);
});