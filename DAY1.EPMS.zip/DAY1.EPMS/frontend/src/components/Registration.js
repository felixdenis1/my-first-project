import React, { useState } from 'react';
import axios from 'axios';
import { useNavigate } from 'react-router-dom';

export default function Registration() {
  const [user, setUser] = useState({ username: '', password: '' });
  const navigate = useNavigate();


  const handleChange = e => setUser({ ...user, [e.target.name]: e.target.value });

  const handleSubmit = async e => {
    e.preventDefault();
    try {
      await axios.post('http://localhost:5000/register', user);
      alert('Registration successful! You can now login.');
      setTimeout(() => navigate('/login'), 1000);
    } catch {
      alert('Registration failed');
    }
  };

  return (
    <form onSubmit={handleSubmit} className="max-w-sm mx-auto p-4 bg-white shadow rounded space-y-4">
      <div>
        <label className="block text-sm font-medium mb-1">Username</label>
        <input
          name="username"
          value={user.username}
          onChange={handleChange}
          className="w-full border p-2 rounded focus:outline-none focus:ring"
          required
        />
      </div>
      <div>
        <label className="block text-sm font-medium mb-1">Password</label>
        <input
          name="password"
          type="password"
          value={user.password}
          onChange={handleChange}
          className="w-full border p-2 rounded focus:outline-none focus:ring"
          required
        />
      </div>
      <button type="submit" className="w-full bg-green-600 text-white p-2 rounded hover:bg-green-700">
        Register
      </button>

      <div className="mt-4 text-center">
          <p className="text-gray-600 text-sm">
            Already have an account?{' '}
            <a 
              href="/register" 
              className="text-blue-500 hover:text-blue-800 font-semibold"
              onClick={(e) => {
                e.preventDefault();
                navigate('/Login');
              }}
            >
              Login 
            </a>
          </p>
        </div>
    </form>
  );
}