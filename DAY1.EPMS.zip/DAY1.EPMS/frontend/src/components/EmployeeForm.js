import React, { useState, useEffect } from 'react';
import axios from 'axios';

export default function EmployeeForm() {
  const [formData, setFormData] = useState({
    EmployeeNumber: '',
    FirstName: '',
    LastName: '',
    Position: '',
    Address: '',
    Telephone: '',
    Gender: '',
    HiredDate: '',
    DepartmentCode: ''
  });
  const [departments, setDepartments] = useState([]);
  const [error, setError] = useState(null);
  const [success, setSuccess] = useState(false);
  const [isLoading, setIsLoading] = useState(false);

  // Fetch departments on component mount
  useEffect(() => {
    const fetchDepartments = async () => {
      try {
        const response = await axios.get('http://localhost:5000/departments');
        setDepartments(response.data);
      } catch (err) {
        console.error("Failed to fetch departments:", err);
        setError('Failed to load departments');
      }
    };
    fetchDepartments();
  }, []);

  const handleChange = e => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  const handleSubmit = async e => {
    e.preventDefault();
    setError(null);
    setSuccess(false);
    setIsLoading(true);

    try {
      // Validate inputs
      const empNumber = parseInt(formData.EmployeeNumber);
      if (isNaN(empNumber)) {
        throw new Error('Employee Number must be a number');
      }
      if (empNumber <= 0) {
        throw new Error('Employee Number must be positive');
      }
      if (!formData.HiredDate || isNaN(new Date(formData.HiredDate).getTime())) {
        throw new Error('Please enter a valid date');
      }

      const payload = {
        ...formData,
        EmployeeNumber: empNumber,
        HiredDate: formData.HiredDate.split('T')[0] // Format date
      };

      const response = await axios.post('http://localhost:5000/employees', payload);
      
      setSuccess(true);
      setFormData({
        EmployeeNumber: '',
        FirstName: '',
        LastName: '',
        Position: '',
        Address: '',
        Telephone: '',
        Gender: '',
        HiredDate: '',
        DepartmentCode: ''
      });
    } catch (err) {
      console.error("Error:", err);
      setError(err.response?.data?.message || err.message || 'Failed to create employee');
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <form onSubmit={handleSubmit} className="max-w-xl mx-auto p-4 bg-white shadow rounded space-y-4">
      {error && (
        <div className="p-3 bg-red-100 text-red-700 rounded">
          {error}
        </div>
      )}
      {success && (
        <div className="p-3 bg-green-100 text-green-700 rounded">
          Employee created successfully!
        </div>
      )}

      <div>
        <label className="block text-sm font-medium mb-1">
          Employee Number <span className="text-red-500">*</span>
        </label>
        <input
          name="EmployeeNumber"
          type="number"
          value={formData.EmployeeNumber}
          onChange={handleChange}
          className="w-full border p-2 rounded focus:outline-none focus:ring"
          required
          min="1"
        />
      </div>

      <div>
        <label className="block text-sm font-medium mb-1">
          First Name <span className="text-red-500">*</span>
        </label>
        <input
          name="FirstName"
          type="text"
          value={formData.FirstName}
          onChange={handleChange}
          className="w-full border p-2 rounded focus:outline-none focus:ring"
          required
        />
      </div>

      <div>
        <label className="block text-sm font-medium mb-1">
          Last Name <span className="text-red-500">*</span>
        </label>
        <input
          name="LastName"
          type="text"
          value={formData.LastName}
          onChange={handleChange}
          className="w-full border p-2 rounded focus:outline-none focus:ring"
          required
        />
      </div>

      <div>
        <label className="block text-sm font-medium mb-1">
          Position <span className="text-red-500">*</span>
        </label>
        <input
          name="Position"
          type="text"
          value={formData.Position}
          onChange={handleChange}
          className="w-full border p-2 rounded focus:outline-none focus:ring"
          required
        />
      </div>

      <div>
        <label className="block text-sm font-medium mb-1">
          Address <span className="text-red-500">*</span>
        </label>
        <input
          name="Address"
          type="text"
          value={formData.Address}
          onChange={handleChange}
          className="w-full border p-2 rounded focus:outline-none focus:ring"
          required
        />
      </div>

      <div>
        <label className="block text-sm font-medium mb-1">
          Telephone <span className="text-red-500">*</span>
        </label>
        <input
          name="Telephone"
          type="tel"
          value={formData.Telephone}
          onChange={handleChange}
          className="w-full border p-2 rounded focus:outline-none focus:ring"
          required
          pattern="[0-9]{10}"
          title="Please enter a 10-digit phone number"
        />
      </div>

      <div>
        <label className="block text-sm font-medium mb-1">
          Gender <span className="text-red-500">*</span>
        </label>
        <select
          name="Gender"
          value={formData.Gender}
          onChange={handleChange}
          className="w-full border p-2 rounded focus:outline-none focus:ring"
          required
        >
          <option value="">Select Gender</option>
          <option value="Male">Male</option>
          <option value="Female">Female</option>
          <option value="Other">Other</option>
        </select>
      </div>

      <div>
        <label className="block text-sm font-medium mb-1">
          Hired Date <span className="text-red-500">*</span>
        </label>
        <input
          name="HiredDate"
          type="date"
          value={formData.HiredDate}
          onChange={handleChange}
          className="w-full border p-2 rounded focus:outline-none focus:ring"
          required
        />
      </div>

      <div>
        <label className="block text-sm font-medium mb-1">
          Department <span className="text-red-500">*</span>
        </label>
        <select
          name="DepartmentCode"
          value={formData.DepartmentCode}
          onChange={handleChange}
          className="w-full border p-2 rounded focus:outline-none focus:ring"
          required
          disabled={departments.length === 0}
        >
          <option value="">Select Department</option>
          {departments.map(dept => (
            <option key={dept.DepartmentCode} value={dept.DepartmentCode}>
              {dept.DepartmentName} ({dept.DepartmentCode})
            </option>
          ))}
        </select>
        {departments.length === 0 && (
          <p className="text-sm text-red-500 mt-1">Loading departments...</p>
        )}
      </div>

      <button 
        type="submit" 
        className={`w-full p-2 rounded text-white ${isLoading ? 'bg-blue-400' : 'bg-blue-600 hover:bg-blue-700'}`}
        disabled={isLoading || success}
      >
        {isLoading ? 'Processing...' : success ? 'Saved!' : 'Save Employee'}
      </button>
    </form>
  );
}