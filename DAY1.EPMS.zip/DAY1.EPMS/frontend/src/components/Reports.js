import React, { useState, useEffect } from 'react';
import axios from 'axios';

export default function SalaryReport() {
  const [salaries, setSalaries] = useState([]);
  const [formData, setFormData] = useState({
    EmployeeNumber: '',
    GrossSalary: '',
    TotalDeduction: '',
    NetSalary: '',
    Month: ''
  });
  const [editingId, setEditingId] = useState(null);

  useEffect(() => {
    fetchSalaries();
  }, []);

  const fetchSalaries = async () => {
    try {
      const response = await axios.get('http://localhost:5000/salaries');
      setSalaries(response.data);
    } catch (error) {
      console.error('Error fetching salaries:', error);
    }
  };

  const handleChange = e => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  const handleSubmit = async e => {
    e.preventDefault();
    try {
      const payload = {
        ...formData,
        EmployeeNumber: parseInt(formData.EmployeeNumber),
        GrossSalary: parseFloat(formData.GrossSalary),
        TotalDeduction: parseFloat(formData.TotalDeduction),
        NetSalary: parseFloat(formData.NetSalary)
      };

      if (editingId) {
        await axios.put(`http://localhost:5000/salaries/${editingId}`, payload);
        alert('Salary record updated successfully');
      } else {
        await axios.post('http://localhost:5000/salaries', payload);
        alert('Salary record added successfully');
      }
      resetForm();
      fetchSalaries();
    } catch (error) {
      console.error('Error saving salary:', error);
    }
  };

  const handleEdit = (salary) => {
    setFormData({
      EmployeeNumber: salary.EmployeeNumber.toString(),
      GrossSalary: salary.GrossSalary.toString(),
      TotalDeduction: salary.TotalDeduction.toString(),
      NetSalary: salary.NetSalary.toString(),
      Month: salary.Month
    });
    setEditingId(salary.SalaryID);
  };

  const handleDelete = async (id) => {
    if (window.confirm('Are you sure you want to delete this salary record?')) {
      try {
        await axios.delete(`http://localhost:5000/salaries/${id}`);
        alert('Salary record deleted successfully');
        fetchSalaries();
      } catch (error) {
        console.error('Error deleting salary:', error);
      }
    }
  };

  const resetForm = () => {
    setFormData({
      EmployeeNumber: '',
      FirstName : '',
      LastName : '',
      GrossSalary: '',
      TotalDeduction: '',
      NetSalary: '',
      Month: ''
    });
    setEditingId(null);
  };

  // Helper function to format currency values safely
  const formatCurrency = (value) => {
    if (value === null || value === undefined) return '$0.00';
    const num = typeof value === 'string' ? parseFloat(value) : value;
    return isNaN(num) ? '$0.00' : `$${num.toFixed(2)}`;
  };

  return (
    <div className="container mx-auto p-4">
      <h1 className="text-2xl font-bold mb-6">Salary Report</h1>
      
      {/* Salary Form */}
      <div className="bg-white p-4 rounded-lg shadow-md mb-6">
        <h2 className="text-xl font-semibold mb-4">
          {editingId ? 'Edit Salary Record' : 'Add New Salary Record'}
        </h2>
        <form onSubmit={handleSubmit} className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div>
            <label className="block text-sm font-medium mb-1">Employee Number</label>
            <input
              name="EmployeeNumber"
              type="number"
              value={formData.EmployeeNumber}
              onChange={handleChange}
              className="w-full border p-2 rounded"
              required
            />
          </div>
          
          <div>
            <label className="block text-sm font-medium mb-1">Gross Salary</label>
            <input
              name="GrossSalary"
              type="number"
              step="0.01"
              value={formData.GrossSalary}
              onChange={handleChange}
              className="w-full border p-2 rounded"
              required
            />
          </div>
          
          <div>
            <label className="block text-sm font-medium mb-1">Total Deduction</label>
            <input
              name="TotalDeduction"
              type="number"
              step="0.01"
              value={formData.TotalDeduction}
              onChange={handleChange}
              className="w-full border p-2 rounded"
              required
            />
          </div>
          
          <div>
            <label className="block text-sm font-medium mb-1">Net Salary</label>
            <input
              name="NetSalary"
              type="number"
              step="0.01"
              value={formData.NetSalary}
              onChange={handleChange}
              className="w-full border p-2 rounded"
              required
            />
          </div>
          
          <div>
            <label className="block text-sm font-medium mb-1">Month</label>
            <input
              name="Month"
              type="text"
              value={formData.Month}
              onChange={handleChange}
              className="w-full border p-2 rounded"
              required
            />
          </div>
          
          <div className="md:col-span-2 flex space-x-4">
            <button
              type="submit"
              className="bg-blue-600 text-white px-4 py-2 rounded hover:bg-blue-700"
            >
              {editingId ? 'Update' : 'Save'} Record
            </button>
            {editingId && (
              <button
                type="button"
                onClick={resetForm}
                className="bg-gray-500 text-white px-4 py-2 rounded hover:bg-gray-600"
              >
                Cancel
              </button>
            )}
          </div>
        </form>
      </div>

      {/* Salary Table */}
      <div className="bg-white rounded-lg shadow-md overflow-hidden">
        <div className="overflow-x-auto">
          <table className="min-w-full divide-y divide-gray-200">
            <thead className="bg-gray-50">
              <tr>
          
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Employee </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Employee </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Gross Salary</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Deductions</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Net Salary</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Month</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Actions</th>
              </tr>
            </thead>
            <tbody className="bg-white divide-y divide-gray-200">
              {salaries.map(salary => (
                <tr key={salary.SalaryID} className="hover:bg-gray-50">
                
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">{salary.EmployeeNumber}</td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">{salary.FirstName}</td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">{formatCurrency(salary.GrossSalary)}</td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">{formatCurrency(salary.TotalDeduction)}</td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">{formatCurrency(salary.NetSalary)}</td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">{salary.Month}</td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm font-medium">
                    <button
                      onClick={() => handleEdit(salary)}
                      className="text-indigo-600 hover:text-indigo-900 mr-3"
                    >
                      Edit
                    </button>
                    <button
                      onClick={() => handleDelete(salary.SalaryID)}
                      className="text-red-600 hover:text-red-900"
                    >
                      Delete
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}