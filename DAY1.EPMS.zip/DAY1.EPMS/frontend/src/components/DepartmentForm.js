import React, { useState } from 'react';
import axios from 'axios';

function DepartmentForm() {
  const [form, setForm] = useState({
    DepartmentCode: '',
    DepartmentName: '',
    GrossSalary: '',
    TotalDeduction: ''
  });

  const [errors, setErrors] = useState({});
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [submitStatus, setSubmitStatus] = useState({ success: false, message: '' });

  const validateForm = () => {
    const newErrors = {};
    
    // Required field validation
    if (!form.DepartmentCode.trim()) newErrors.DepartmentCode = 'Department code is required';
    if (!form.DepartmentName.trim()) newErrors.DepartmentName = 'Department name is required';
    
    // Numeric validation
    if (form.GrossSalary && isNaN(form.GrossSalary)) {
      newErrors.GrossSalary = 'Must be a valid number';
    }
    if (form.TotalDeduction && isNaN(form.TotalDeduction)) {
      newErrors.TotalDeduction = 'Must be a valid number';
    }
    
    // Positive number validation
    if (form.GrossSalary && parseFloat(form.GrossSalary) <= 0) {
      newErrors.GrossSalary = 'Must be greater than 0';
    }
    if (form.TotalDeduction && parseFloat(form.TotalDeduction) < 0) {
      newErrors.TotalDeduction = 'Cannot be negative';
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleChange = (e) => {
    const { name, value } = e.target;
    setForm(prev => ({
      ...prev,
      [name]: value
    }));
    
    // Clear error when user starts typing
    if (errors[name]) {
      setErrors(prev => ({ ...prev, [name]: '' }));
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    
    if (!validateForm()) return;
    
    setIsSubmitting(true);
    setSubmitStatus({ success: false, message: '' });

    try {
      const response = await axios.post('http://localhost:5000/department', form);
      setSubmitStatus({
        success: true,
        message: response.data.message || 'Department added successfully!'
      });
      
      // Reset form after successful submission
      setForm({
        DepartmentCode: '',
        DepartmentName: '',
        GrossSalary: '',
        TotalDeduction: ''
      });
    } catch (error) {
      console.error('Department submission error:', error);
      
      let errorMessage = 'Failed to add department';
      if (error.response) {
        // Server responded with error status
        errorMessage = error.response.data.message || errorMessage;
        
        // Handle validation errors from server
        if (error.response.data.errors) {
          const serverErrors = {};
          error.response.data.errors.forEach(err => {
            serverErrors[err.path] = err.message;
          });
          setErrors(serverErrors);
        }
      } else if (error.request) {
        // Request was made but no response received
        errorMessage = 'Network error - please check your connection';
      }
      
      setSubmitStatus({
        success: false,
        message: errorMessage
      });
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="max-w-md mx-auto p-6 bg-white rounded-lg shadow-md">
      <h2 className="text-2xl font-bold mb-6 text-gray-800">Add New Department</h2>
      
      {submitStatus.message && (
        <div className={`mb-4 p-3 rounded ${submitStatus.success ? 'bg-green-100 text-green-700' : 'bg-red-100 text-red-700'}`}>
          {submitStatus.message}
        </div>
      )}
      
      <form onSubmit={handleSubmit} className="space-y-4">
        {Object.keys(form).map((key) => (
          <div key={key}>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              {key.replace(/([A-Z])/g, ' $1').trim()}
            </label>
            <input
              name={key}
              value={form[key]}
              onChange={handleChange}
              className={`w-full px-3 py-2 border rounded-md ${errors[key] ? 'border-red-500 focus:ring-red-500' : 'border-gray-300 focus:ring-blue-500'} focus:outline-none focus:ring-1`}
            />
            {errors[key] && <p className="mt-1 text-sm text-red-600">{errors[key]}</p>}
          </div>
        ))}
        
        <button
          type="submit"
          disabled={isSubmitting}
          className={`w-full py-2 px-4 rounded-md text-white font-medium transition-colors ${isSubmitting ? 'bg-gray-400 cursor-not-allowed' : 'bg-green-600 hover:bg-green-700'}`}
        >
          {isSubmitting ? (
            <span className="flex items-center justify-center">
              <svg className="animate-spin -ml-1 mr-2 h-4 w-4 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
              </svg>
              Processing...
            </span>
          ) : 'Add Department'}
        </button>
      </form>
    </div>
  );
}

export default DepartmentForm;