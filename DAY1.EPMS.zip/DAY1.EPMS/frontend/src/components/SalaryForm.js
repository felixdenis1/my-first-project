import React, { useState } from 'react';
import axios from 'axios';

export default function SalaryForm() {
  const [data, setData] = useState({
    EmployeeNumber: '',
    GrossSalary: '',
    TotalDeduction: '',
    NetSalary: '',
    Month: ''
  });

  const handleChange = e => setData({ ...data, [e.target.name]: e.target.value });

  const handleSubmit = async e => {
    e.preventDefault();
    await axios.post('http://localhost:5000/salaries', data);
    alert('Salary record added');
  };

  return (
    <form onSubmit={handleSubmit} className="max-w-md mx-auto p-4 bg-white shadow rounded space-y-4">
      {[
        { label: 'Employee Number', name: 'EmployeeNumber', type: 'number' },
        { label: 'Gross Salary',     name: 'GrossSalary',     type: 'number', step: '0.01' },
        { label: 'Total Deduction',  name: 'TotalDeduction',  type: 'number', step: '0.01' },
        { label: 'Net Salary',       name: 'NetSalary',       type: 'number', step: '0.01' },
        { label: 'Month',            name: 'Month' }
      ].map(f => (
        <div key={f.name}>
          <label className="block text-sm font-medium mb-1">{f.label}</label>
          <input
            name={f.name}
            type={f.type || 'text'}
            step={f.step}
            value={data[f.name]}
            onChange={handleChange}
            className="w-full border p-2 rounded focus:outline-none focus:ring"
          />
        </div>
      ))}
      <button type="submit" className="w-full bg-green-600 text-white p-2 rounded hover:bg-green-700">
        Save Salary
      </button>
    </form>
  );
}
