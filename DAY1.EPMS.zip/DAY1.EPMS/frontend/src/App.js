import React from 'react';
import { BrowserRouter as Router, Route, Routes, Link, Navigate } from 'react-router-dom';
import EmployeeForm from './components/EmployeeForm';
import DepartmentForm from './components/DepartmentForm';
import SalaryForm from './components/SalaryForm';
import Reports from './components/Reports';
import Login from './components/Login';
import Registration from './components/Registration';

function App() {
  const [isAuthenticated, setIsAuthenticated] = React.useState(false);

  const handleLogin = () => {
    setIsAuthenticated(true);
  };

  const handleLogout = () => {
    setIsAuthenticated(false);
  };

  return (
    <Router>
      <div className="p-4">
        {isAuthenticated ? (
          <>
            <nav className="bg-blue-600 text-white p-4 rounded-xl mb-4">
              <ul className="flex gap-4">
                <li><Link to="/">Employee</Link></li>
                <li><Link to="/department">Department</Link></li>
                <li><Link to="/salary">Salary</Link></li>
                <li><Link to="/reports">Reports</Link></li>
                <li><button onClick={handleLogout}>Logout</button></li>
              </ul>
            </nav>
            <Routes>
              <Route path="/" element={<EmployeeForm />} />
              <Route path="/department" element={<DepartmentForm />} />
              <Route path="/salary" element={<SalaryForm />} />
              <Route path="/reports" element={<Reports />} />
              <Route path="*" element={<Navigate to="/" />} />
            </Routes>
          </>
        ) : (
          <Routes>
            <Route path="/login" element={<Login onLogin={handleLogin} />} />
            <Route path="/register" element={<Registration />} />
            <Route path="*" element={<Navigate to="/login" />} />
          </Routes>
        )}
      </div>
    </Router>
  );
}

export default App;