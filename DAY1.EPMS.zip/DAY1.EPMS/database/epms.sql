CREATE DATABASE IF NOT EXISTS EPMS;
USE EPMS;

CREATE TABLE Department (
  DepartmentCode VARCHAR(10) PRIMARY KEY,
  DepartmentName VARCHAR(100),
  GrossSalary DECIMAL(10,2),
  TotalDeduction DECIMAL(10,2)
);

CREATE TABLE Employee (
  EmployeeNumber INT PRIMARY KEY,
  FirstName VARCHAR(100),
  LastName VARCHAR(100),
  Position VARCHAR(100),
  Address TEXT,
  Telephone VARCHAR(20),
  Gender VARCHAR(10),
  HiredDate DATE,
  DepartmentCode VARCHAR(10),
  FOREIGN KEY (DepartmentCode) REFERENCES Department(DepartmentCode)
);

CREATE TABLE Salary (
  SalaryID INT AUTO_INCREMENT PRIMARY KEY,
  EmployeeNumber INT,
  GrossSalary DECIMAL(10,2),
  TotalDeduction DECIMAL(10,2),
  NetSalary DECIMAL(10,2),
  Month VARCHAR(20),
  FOREIGN KEY (EmployeeNumber) REFERENCES Employee(EmployeeNumber)
);
CREATE TABLE users (
  id INT AUTO_INCREMENT PRIMARY KEY,
  username VARCHAR(100),
  password VARCHAR(100)
);