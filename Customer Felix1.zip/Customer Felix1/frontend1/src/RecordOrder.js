import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';

function Register() {
  const [order_number, setorder_number] = useState('');
  const [order_date, setorder_date] = useState('');
  const [productcode, setproductcode] = useState('');
  const [cust_id, setcust_id] = useState('');
  const [productCodes, setProductCodes] = useState([]);
  const [customers, setCustomers] = useState([]);

  const navigate = useNavigate();

  useEffect(() => {
    // Fetch all product codes
    fetch('http://localhost:8009/productcodes')
      .then(res => res.json())
      .then(data => setProductCodes(data))
      .catch(err => console.error('Error fetching product codes:', err));

    // Fetch all customer ids and names
    fetch('http://localhost:8009/customerids')
      .then(res => res.json())
      .then(data => setCustomers(data))
      .catch(err => console.error('Error fetching customer ids:', err));
  }, []);

  const handleRegister = async (e) => {
    e.preventDefault();

    try {
      const res = await fetch('http://localhost:8009/commands', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ order_number, order_date, productcode, cust_id })
      });

      if (!res.ok) {
        const errorText = await res.text();
        throw new Error(`Failed to register: ${errorText}`);
      }

      const data = await res.json();
      alert(data.message);

      navigate('/Orders');
    } catch (error) {
      console.error('Registration failed:', error);
      alert('Error during registration');
    }
  };

  return (
    <div className="form">
      <h1>ORDERS FORM</h1>
      <form onSubmit={handleRegister}>
        <input
          type="text"
          value={order_number}
          placeholder="Order Number"
          onChange={(e) => setorder_number(e.target.value)}
        /><br /><br />

        <input
          type="date"
          value={order_date}
          onChange={(e) => setorder_date(e.target.value)}
        /><br /><br />

        {/* Select for Product Code */}
        <select value={productcode} onChange={(e) => setproductcode(e.target.value)}>
          <option value="">-- Select Product Code --</option>
          {productCodes.map((prod, index) => (
            <option key={index} value={prod.productcode}>
              {prod.productcode}
            </option>
          ))}
        </select><br /><br />

        {/* Select for Customer ID */}
        <select value={cust_id} onChange={(e) => setcust_id(e.target.value)}>
          <option value="">-- Select Customer --</option>
          {customers.map((cust, index) => (
            <option key={index} value={cust.cust_id}>
              {cust.cust_id} - {cust.cust_fname} {cust.cust_lname}
            </option>
          ))}
        </select><br /><br />

        <button type="submit">Register Order</button><br /><br />

        <div className="back"><a href="/Dashboard">Back</a></div>
      </form>
    </div>
  );
}

export default Register;
