import React, { useEffect, useState } from 'react';
import axios from 'axios';
import './App';

const CustomerList = () => {
  const [customers, setCustomers] = useState([]);
  const [loading, setLoading] = useState(true);
  const [editCustomer, setEditCustomer] = useState(null); // store the customer being edited

  useEffect(() => {
    fetchCustomers();
  }, []);

  const fetchCustomers = () => {
    axios.get('http://localhost:8009/Customers')
      .then(response => {
        setCustomers(response.data);
        setLoading(false);
      })
      .catch(error => {
        console.error('Error fetching customers:', error);
        setLoading(false);
      });
  };

  const deleteCustomer = (cust_id) => {
    if (!window.confirm('Are you sure you want to delete this customer?')) return;

    axios.delete(`http://localhost:8009/Customers/${cust_id}`)
      .then(() => {
        setCustomers(customers.filter(c => c.cust_id !== cust_id));
      })
      .catch(error => {
        console.error('Error deleting customer:', error);
      });
  };

  const handleEditClick = (customer) => {
    setEditCustomer({ ...customer }); // clone the customer object
  };

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setEditCustomer(prev => ({ ...prev, [name]: value }));
  };

  const handleUpdate = () => {
    axios.put(`http://localhost:8009/Customers/${editCustomer.cust_id}`, editCustomer)
      .then(() => {
        setEditCustomer(null);
        fetchCustomers();
      })
      .catch(error => {
        console.error('Error updating customer:', error);
      });
  };

  if (loading) return <p>Loading customers...</p>;

  return (
    <div>
     <div class="hac"><h2>CUSTOMERS LIST</h2></div> 
      <table border="1" cellPadding="5">
        <thead>
          <tr>
            <th>ID</th>
            <th>First Name</th>
            <th>Last Name</th>
            <th>Location</th>
            <th>Telephone</th>
            <th>Actions</th>
          </tr>
        </thead>
        <tbody>
          {customers.map(cust => (
            <tr key={cust.cust_id}>
              <td>{cust.cust_id}</td>
              <td>{cust.cust_fname}</td>
              <td>{cust.cust_lname}</td>
              <td>{cust.location}</td>
              <td>{cust.telephone}</td>
              <td>
                <button onClick={() => handleEditClick(cust)}>Edit</button>{' '}
                <button onClick={() => deleteCustomer(cust.cust_id)} style={{ color: 'white',background:'red' }}>
                  Exit
                </button>
              </td>
            </tr>
          ))}
        </tbody>
      </table>

      {editCustomer && (
        <div style={{ marginTop: '20px' }}>
          <h3>Edit Customer (ID: {editCustomer.cust_id})</h3>
          <form onSubmit={e => { e.preventDefault(); handleUpdate(); }}>
            <input
              type="text"
              name="cust_fname"
              value={editCustomer.cust_fname}
              onChange={handleInputChange}
              placeholder="First Name"
              required
            />
            <input
              type="text"
              name="cust_lname"
              value={editCustomer.cust_lname}
              onChange={handleInputChange}
              placeholder="Last Name"
              required
            />
            <input
              type="text"
              name="location"
              value={editCustomer.location}
              onChange={handleInputChange}
              placeholder="Location"
              required
            />
            <input
              type="text"
              name="telephone"
              value={editCustomer.telephone}
              onChange={handleInputChange}
              placeholder="Telephone"
              required
            />
            <button type="submit">Update</button>
            <button type="button" onClick={() => setEditCustomer(null)}>Cancel</button>
          </form>
        </div>
      )}<br/><br/><div class="back"><a href="Dashboard">Back</a></div>
    </div>
  );
};

export default CustomerList;
