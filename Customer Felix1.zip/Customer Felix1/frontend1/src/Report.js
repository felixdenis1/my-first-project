import React, { useEffect, useState } from 'react';
import axios from 'axios';

const Report = () => {
  const [reports, setReports] = useState([]);
  const [loading, setLoading] = useState(true);
  const [isEditing, setIsEditing] = useState(false);
  const [editOrder, setEditOrder] = useState(null);

  useEffect(() => {
    fetchReports();
  }, []);

  const fetchReports = () => {
    axios.get('http://localhost:8009/CustomerOrders')
      .then(response => {
        setReports(response.data);
        setLoading(false);
      })
      .catch(error => {
        console.error('Error fetching report:', error);
        setLoading(false);
      });
  };

  const handleDelete = (order_number) => {
    if (!window.confirm('Are you sure you want to delete this order?')) return;
    axios.delete(`http://localhost:8009/orders/${order_number}`)
      .then(response => {
        alert(response.data.message);
        fetchReports(); // Refresh the list after deletion
      })
      .catch(error => {
        console.error('Error deleting order:', error);
        alert('Error deleting order');
      });
  };

  const handleEdit = (order) => {
    setIsEditing(true);
    setEditOrder(order);
  };

  const handleUpdate = () => {
    axios.put(`http://localhost:8009/orders/${editOrder.order_number}`, {
      order_date: editOrder.order_date,
      productcode: editOrder.productcode,
      cust_id: editOrder.cust_id,
    })
    .then(response => {
      alert(response.data.message);
      setIsEditing(false);
      setEditOrder(null);
      fetchReports(); // Refresh the list after updating
    })
    .catch(error => {
      console.error('Error updating order:', error);
      alert('Error updating order');
    });
  };

  if (loading) return <p>Loading report...</p>;

  return (
    <div>
      <div className="hac"><h2>Customers Order Report</h2></div>
      {reports.length === 0 ? (
        <p>No orders found.</p>
      ) : (
        <table border="1" cellPadding="8">
          <thead>
            <tr>
              <th>Order Number</th>
              <th>Order Date</th>
              <th>Product Code</th>
              <th>Customer ID</th>
              <th>Customer Name</th>
              <th>Location</th>
              <th>Telephone</th>
              <th>Actions</th>
            </tr>
          </thead>
          <tbody>
            {reports.map((row, index) => (
              <tr key={index}>
                <td>{row.order_number}</td>
                <td>
                  {row.order_date && new Date(row.order_date).toLocaleDateString('en-GB')}
                </td>
                <td>{row.productcode}</td>
                <td>{row.cust_id}</td>
                <td>{row.cust_fname} {row.cust_lname}</td>
                <td>{row.location}</td>
                <td>{row.telephone}</td>
                <td>
                  <button onClick={() => handleEdit(row)}>Edit</button>
                  <button onClick={() => handleDelete(row.order_number)} style={{ color: 'white',background:'red' }}>Delete</button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      )}

      {isEditing && (
        <div>
          <h3>Edit Order</h3>
          <form onSubmit={e => { e.preventDefault(); handleUpdate(); }}>
            <input 
              type="date" 
              value={editOrder.order_date} 
              onChange={e => setEditOrder({ ...editOrder, order_date: e.target.value })} 
            />
            <input 
              type="text" 
              value={editOrder.productcode} 
              onChange={e => setEditOrder({ ...editOrder, productcode: e.target.value })} 
            />
            <input 
              type="number" 
              value={editOrder.cust_id} 
              onChange={e => setEditOrder({ ...editOrder, cust_id: e.target.value })} 
            />
            <button type="submit">Update Order</button>
            <button onClick={() => setIsEditing(false)}>Cancel</button>
          </form>
        </div>
      )}
      <br/>  <br/><div class="back"><a href="Dashboard">Back</a></div>
    </div>
  );
};

export default Report;
