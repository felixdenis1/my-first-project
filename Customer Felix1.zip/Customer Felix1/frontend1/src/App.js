import React,{useState} from 'react';
import { BrowserRouter as Router, Routes, Route, Link } from 'react-router-dom';
import Dashboard from './Dashboard';
import Register from './Register';
import Login from './Login';
import Products from './Products';
import CustomerOrder from './CustomerOder';
import RecordOrder from './RecordOrder';
import Customers from './Customers';
import Orders from './Orders';
import Report  from './Report';
import './App.css';

function App(){

return (
   
    <Router> 
<Routes>
<Route path='/' element={<Register/>} ></Route>
<Route path='/Dashboard' element={<Dashboard/>}></Route>
<Route path='/Register' element={<Register/>} ></Route>
<Route path='/Login' element={<Login/>} ></Route>
<Route path='/Products' element={<Products/>} ></Route>
<Route path='/CustomerOrder' element={<CustomerOrder/>} ></Route>
<Route path='/RecordOrder' element={<RecordOrder/>} ></Route>
<Route path='/Customers' element={<Customers/>} ></Route>
<Route path='/Orders' element={<Orders/>} ></Route>
<Route path='/Report' element={<Report/>} ></Route>

</Routes>
</Router>
   
)}


export default App;