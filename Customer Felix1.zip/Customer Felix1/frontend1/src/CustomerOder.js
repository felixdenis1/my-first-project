import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';

function Register() {
  const [cust_id, setcust_id] = useState('');
  const [cust_fname, setcust_fname] = useState('');
  const [cust_lname, setcust_lname] = useState('');
  const [location, setlocation] = useState('');
  const [telephone, settelephone] = useState('');
 

  const navigate = useNavigate();

  const handleRegister = async (e) => {
    e.preventDefault();

    try {
      const res = await fetch('http://localhost:8009/Customers', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ cust_id,cust_fname,cust_lname,location,telephone})
      });

      if (!res.ok) {
        const errorText = await res.text();
        throw new Error(`Failed to register: ${errorText}`);
      }

      const data = await res.json();
      alert(data.message);

      navigate('/Customers');
    } 
    catch (error) {
      console.error('Registration failed:', error);
      alert('Error during registration');
    }
  };

  return (
    <div class="form">
      <h1>CUSTOMER FORM</h1>
      <form onSubmit={handleRegister}>
        <input
          type="text"
          value={cust_id}
          placeholder="Id"
          onChange={(e) => setcust_id(e.target.value)}
        /><br/><br/>
       <input
          type="text"
          value={cust_fname}
          placeholder="First Name"
          onChange={(e) => setcust_fname(e.target.value)}
        /><br/><br/>
        <input
          type="text"
          value={cust_lname}
          placeholder="Last Name"
          onChange={(e) => setcust_lname(e.target.value)}
        /><br/><br/>
        <input
          type="text"
          value={location}
          placeholder="Location"
          onChange={(e) => setlocation(e.target.value)}
        /><br/><br/>
        <input
          type="number"
          value={telephone}
          placeholder="Phone"
          onChange={(e) => settelephone(e.target.value)}
        /><br/><br/>
      
        <button type="submit">Register</button> 
        <br/><br/><div class="back"><a href="Dashboard">Back</a></div>

      </form>
    </div>
  );
}

export default Register;
