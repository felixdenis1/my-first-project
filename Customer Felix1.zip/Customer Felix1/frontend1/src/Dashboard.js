import React,{useState, } from 'react';
import {useNavigate,Link} from 'react-router-dom';
import './App.css';

function Dashboard (){

return(

    <div>

   <div class="twe"> <nav>
    <div class="dash">
        <h1>Dashboard</h1>
    </div>
<div class="den">
   
<ul>
    <Link to='/CustomerOrder' >Manage CustomerOrder </Link><br/><br/>
    <Link to='/RecordOrder' >Manage RecordOrder </Link><br/><br/>
    <Link to='/Report' >View Reports </Link><br/><br/>
    <Link to='/Products' > Generate Products </Link><br/><br/>
    <Link to='/Customers' > Customers </Link><br/><br/>
    <Link to='/Orders' > Orders </Link><br/><br/>

    </ul>   
</div>
</nav>

<div class="lout">
    <a href="Login">Logout</a>
</div>
   </div>

<div class="sa">
<p>WELCOME THIS IS CUSTOMER DASHBOARD !!!</p>
Ariko ko mbona ibi bintu bitazoroha <br/>
Gusa Buriya Imana izongera iHabe!!!
</div>
</div>
)

}

export default Dashboard;