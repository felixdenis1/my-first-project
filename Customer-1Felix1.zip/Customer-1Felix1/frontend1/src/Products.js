import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';

function Register() {
  const [productcode, setproductcode] = useState('');
  const [productname, setproductname] = useState('');
  const [product_quantity, setproduct_quantity] = useState('');
  const [unit_price, setunit_price] = useState('');
 

  const navigate = useNavigate();

  const handleRegister = async (e) => {
    e.preventDefault();

    try {
      const res = await fetch('http://localhost:8009/Orders', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ productcode,productname,product_quantity,unit_price})
      });

      if (!res.ok) {
        const errorText = await res.text();
        throw new Error(`Failed to register: ${errorText}`);
      }

      const data = await res.json();
      alert(data.message);

      navigate('/Dashboard');
    } 
    catch (error) {
      console.error('Registration failed:', error);
      alert('Error during registration');
    }
  };

  return (
    <div class="form">
      <h1>PRODUCTS FORM</h1>
      <form onSubmit={handleRegister}>
        <input
          type="text"
          value={productcode}
          placeholder="product code"
          onChange={(e) => setproductcode(e.target.value)}
        /><br/><br/>
       <input
          type="text"
          value={productname}
          placeholder="product name"
          onChange={(e) => setproductname(e.target.value)}
        /><br/><br/>
        <input
          type="number"
          value={product_quantity}
          placeholder="product quantity"
          onChange={(e) => setproduct_quantity(e.target.value)}
        /><br/><br/>
        <input
          type="number"
          value={unit_price}
          placeholder="uint_price"
          onChange={(e) => setunit_price(e.target.value)}
        /><br/><br/>
      
        <button type="submit">Register product</button> 
        <br/><br/><div class="back"><a href="Dashboard">Back</a></div>

      </form>
    </div>
  );
}

export default Register;
