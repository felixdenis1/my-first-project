import React from 'react';
import { Link } from 'react-router-dom';
import './App.css';

function Dashboard() {
  return (
    <div>
      <div className="twe">
        <nav>
          <div className="dash">
            <h1>Dashboard</h1>
          </div>
          <div className="den">
            <ul>
              <li>
                <Link to="/CustomerOrder">
                  <i className="fas fa-shopping-cart"></i> Manage CustomerOrder
                </Link>
              </li>
              <br />
              <li>
                <Link to="/RecordOrder">
                  <i className="fas fa-list-alt"></i> Manage RecordOrder
                </Link>
              </li>
              <br />
              <li>
                <Link to="/Products">
                  <i className="fas fa-box"></i> Generate Products
                </Link>
              </li>
              <br />
              <li>
                <Link to="/Customers">
                  <i className="fas fa-users"></i> Customers
                </Link>
              </li>
              <br />
              <li>
                <Link to="/Orders">
                  <i className="fas fa-box-open"></i> Orders
                </Link>
              </li>
              <br />
              <li>
                <Link to="/GetProducts">
                  <i className="fas fa-box"></i>  Products
                </Link>
              </li><br/>
              <li>
                <Link to="/Report">
                  <i className="fas fa-chart-bar"></i> View Reports
                </Link>
              </li>
            </ul>
          </div>
        </nav>

        <div className="lout">
          <a href="Login">Logout</a>
        </div>
      </div>

      <div className="sa">
        <p>WELCOME THIS IS CUSTOMER DASHBOARD !!!</p>
        <div class="mar">
    <marquee behavior="scroll" direction="down"  >SERVICES TO CUSTOMERS</marquee>
    <marquee behavior="scroll" direction="left"  >Wowe Tubwire Icyushaka <br/>Tukikugezeho kugihe!!! </marquee>
    </div>
      </div>
    </div>

    
  );
}

export default Dashboard;
