import React, { useEffect, useState } from 'react';
import axios from 'axios';

const OrderList = () => {
  const [orders, setOrders] = useState([]);
  const [editOrder, setEditOrder] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchOrders();
  }, []);

  const fetchOrders = () => {
    axios.get('http://localhost:8009/Orders')
      .then(response => {
        setOrders(response.data);
        setLoading(false);
      })
      .catch(error => {
        console.error('Error fetching orders:', error);
        setLoading(false);
      });
  };

  const deleteOrder = (order_number) => {
    if (!window.confirm('Are you sure you want to delete this order?')) return;

    axios.delete(`http://localhost:8009/Orders/${order_number}`)
      .then(() => {
        setOrders(orders.filter(o => o.order_number !== order_number));
      })
      .catch(error => {
        console.error('Error deleting order:', error);
      });
  };

  const handleEditClick = (order) => {
    setEditOrder({ ...order });
  };

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setEditOrder(prev => ({ ...prev, [name]: value }));
  };

  const handleUpdate = () => {
    axios.put(`http://localhost:8009/Orders/${editOrder.order_number}`, editOrder)
      .then(() => {
        setEditOrder(null);
        fetchOrders();
      })
      .catch(error => {
        console.error('Error updating order:', error);
      });
  };

  if (loading) return <p>Loading orders...</p>;

  return (
    <div>
     <div class="hac"><h2>ORDERS LIST</h2></div> 
      <table border="1" cellPadding="5">
        <thead>
          <tr>
            <th>Order Number</th>
            <th>Order Date</th>
            <th>Product Code</th>
            <th>Customer ID</th>
            <th>Actions</th>
          </tr>
        </thead>
        <tbody>
          {orders.map(order => (
            <tr key={order.order_number}>
              <td>{order.order_number}</td>
              <td>
  {order.order_date &&
    new Date(order.order_date).toLocaleDateString('en-GB')}
</td>

              <td>{order.productcode}</td>
              <td>{order.cust_id}</td>
              <td>
                <button onClick={() => handleEditClick(order)}>Edit</button>{' '}
<button onClick={() => deleteOrder(order.order_number)} style={{ color: 'white',background:'red' }}>Delete</button>
              </td>
            </tr>
          ))}
        </tbody>
      </table>

      {editOrder && (
        <div style={{ marginTop: '20px' }}>
          <h3>Edit Order #{editOrder.order_number}</h3>
          <form onSubmit={e => { e.preventDefault(); handleUpdate(); }}>
            <input
              type="date"
              name="order_date"
              value={editOrder.order_date?.split('T')[0] || ''}
              onChange={handleInputChange}
              required
            />
            <input
              type="text"
              name="productcode"
              value={editOrder.productcode}
              onChange={handleInputChange}
              placeholder="Product Code"
              required
            />
            <input
              type="number"
              name="cust_id"
              value={editOrder.cust_id}
              onChange={handleInputChange}
              placeholder="Customer ID"
              required
            />
            <input
              type="number"
              name="order_number"
              value={editOrder.order_number}
              onChange={handleInputChange}
              placeholder="order size"
              required
            />
            <button type="submit">Update</button>
            <button type="button" onClick={() => setEditOrder(null)}>Cancel</button>
          </form>
        </div> 
      )}
     <br/>  <br/><div class="back"><a href="Dashboard">Back</a></div>
    </div>
  );
};

export default OrderList;
