import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';

function Register() {
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const navigate = useNavigate();

  const handleRegister = async (e) => {
    e.preventDefault();

    try {
      const res = await fetch('http://localhost:8009/Register', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ username, password })
      });

      if (!res.ok) {
        const errorText = await res.text();
        throw new Error(`Failed to register: ${errorText}`);
      }

      const data = await res.json();
      alert(data.message);

      navigate('/Dashboard');
    } 
    catch (error) {
      console.error('Registration failed:', error);
      alert('Error during registration');
    }
  };

  return (
    <div class="form">
      <h1>REGISTRATION FORM</h1>
      <form onSubmit={handleRegister}>
        <input
          type="text"
          value={username}
          placeholder="admin name"
          onChange={(e) => setUsername(e.target.value)}
        /><br/><br/>
        <input
          type="text"
          value={password}
          placeholder="admin password"
          onChange={(e) => setPassword(e.target.value)}
        /><br/><br/>
        <button type="submit">Register</button> <p>already have Account</p> <a href="Login">LOGIN</a>
      </form>
    </div>
  );
}

export default Register;
