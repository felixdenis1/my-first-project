import React, { useEffect, useState } from 'react';
import axios from 'axios';

const GetProduct = () => {
  const [products, setProducts] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchProducts();
  }, []);

  const fetchProducts = () => {
    axios.get('http://localhost:8009/products')
      .then(response => {
        setProducts(response.data);
        setLoading(false);
      })
      .catch(error => {
        console.error('Error fetching products:', error);
        setLoading(false);
      });
  };

  if (loading) return <p>Loading products...</p>;

  return (
    <div><div class="bib" ><p><a href="/Dashboard">BACK</a></p></div>
      <h2>Products List</h2> 
      {products.length === 0 ? (
        <p>No products found.</p>
      ) : (
        <table border="1" cellPadding="8">
          <thead>
            <tr>
              <th>Product Code</th>
              <th>Product Name</th>
              <th>Quantity</th>
              <th>Unit Price</th>
              <th>Total Price</th>
            </tr>
          </thead>
          <tbody>
            {products.map((prod, index) => (
              <tr key={index}>
                <td>{prod.productcode}</td>
                <td>{prod.productname}</td>
                <td>{prod.product_quantity}</td>
                <td>{prod.unit_price}</td>
                <td>{prod.total_price}</td>
              </tr>
            ))}
          </tbody>
        </table>
      )}
      
    </div>
  );
};

export default GetProduct;
